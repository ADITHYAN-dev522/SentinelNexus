import React, { useState } from 'react';
import { Search, Network, Loader2, BarChart3, AlertTriangle } from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';

const VulnScanner = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanResults, setScanResults] = useState([]);

  const vulnData = [
    { severity: 'Critical', count: 8, color: '#ef4444' },
    { severity: 'High', count: 23, color: '#f97316' },
    { severity: 'Medium', count: 45, color: '#eab308' },
    { severity: 'Low', count: 67, color: '#22c55e' }
  ];

  const handleVulnSearch = () => {
    if (!searchQuery.trim()) return;
    setIsScanning(true);
    setTimeout(() => {
      setScanResults([
        { ip: searchQuery, os: 'Ubuntu 20.04', open_ports: [22, 80, 443], vulnerabilities: [
          { cve: 'CVE-2024-8901', severity: 'Critical', service: 'Apache Tomcat' },
          { cve: 'CVE-2024-8902', severity: 'High', service: 'OpenSSL' }
        ]}
      ]);
      setIsScanning(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
          <Search className="mr-2 text-blue-400" size={20} /> Vulnerability Scanner
        </h3>
        <div className="flex space-x-4">
          <input
            type="text"
            placeholder="Enter IP, domain, or range"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 px-4 py-3 bg-gray-700 text-white rounded-lg"
          />
          <button
            onClick={handleVulnSearch}
            disabled={isScanning}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg"
          >
            {isScanning ? <Loader2 className="animate-spin" size={16} /> : <Network size={16} />} Scan
          </button>
        </div>
      </div>

      {scanResults.map((res, idx) => (
        <div key={idx} className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
          <h4 className="text-white font-semibold mb-2">Target: {res.ip}</h4>
          <p className="text-gray-400">OS: {res.os}</p>
          <p className="text-gray-400">Open Ports: {res.open_ports.join(', ')}</p>
          <div className="mt-2">
            {res.vulnerabilities.map((v, i) => (
              <div key={i} className="p-2 bg-gray-700 rounded mb-1">
                <span className="text-white">{v.cve}</span>
                <span className="ml-2 text-sm text-gray-400">{v.service}</span>
                <span className={`ml-2 text-xs ${v.severity === 'Critical' ? 'text-red-400' : 'text-orange-400'}`}>{v.severity}</span>
              </div>
            ))}
          </div>
        </div>
      ))}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
          <h3 className="text-xl text-white mb-4 flex items-center">
            <BarChart3 className="mr-2 text-purple-400" /> Vulnerability Distribution
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={vulnData} cx="50%" cy="50%" outerRadius={80} dataKey="count">
                {vulnData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
          <h3 className="text-xl text-white mb-4 flex items-center">
            <AlertTriangle className="mr-2 text-red-400" /> Critical Vulnerabilities
          </h3>
          <p className="text-gray-300">CVE-2024-8901 requires immediate patching (Apache Tomcat RCE).</p>
        </div>
      </div>
    </div>
  );
};

export default VulnScanner;
