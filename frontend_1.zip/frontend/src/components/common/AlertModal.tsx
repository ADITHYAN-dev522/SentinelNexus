import React from 'react';
import { AlertTriangle, X } from 'lucide-react';

const AlertModal = ({ alert, setSelectedAlert }) => (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div className="bg-gray-800 rounded-2xl p-6 max-w-2xl w-full mx-4 border border-gray-700 shadow-2xl">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-white flex items-center">
          <AlertTriangle className="mr-2 text-red-400" size={24} /> Alert Details
        </h2>
        <button onClick={() => setSelectedAlert(null)} className="text-gray-400 hover:text-white">
          <X size={24} />
        </button>
      </div>
      <div className={`p-4 rounded-lg border`}> 
        <h3 className="text-white font-semibold mb-2">{alert.title}</h3>
        <p className="text-gray-300 mb-3">{alert.details}</p>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><span className="text-gray-400">Source:</span> <span className="text-white">{alert.source}</span></div>
          <div><span className="text-gray-400">Location:</span> <span className="text-white">{alert.location}</span></div>
          <div><span className="text-gray-400">Systems:</span> <span className="text-white">{alert.affected_systems}</span></div>
          <div><span className="text-gray-400">Confidence:</span> <span className="text-white">{alert.confidence}%</span></div>
        </div>
      </div>
      <div className="flex space-x-3 mt-4">
        <button className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg">Escalate</button>
        <button className="flex-1 px-4 py-2 bg-yellow-600 text-white rounded-lg">Investigate</button>
        <button className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg">Resolve</button>
      </div>
    </div>
  </div>
);

export default AlertModal;