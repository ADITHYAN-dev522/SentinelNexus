"""
Vector Memory Module - Enhanced memory system with ChromaDB for semantic search
Provides persistent storage and semantic similarity search for threat intelligence
"""

import chromadb
from chromadb.config import Settings
from chromadb.utils import embedding_functions
import json
from datetime import datetime
from typing import List, Dict, Any
from pathlib import Path

class VectorMemoryModule:
    def __init__(self):
        self.persist_path = 'data/chroma_db'
        Path(self.persist_path).mkdir(parents=True, exist_ok=True)
        
        self.client = chromadb.PersistentClient(path=self.persist_path)
        
        default_ef = embedding_functions.DefaultEmbeddingFunction()
        
        self.incidents_collection = self.client.get_or_create_collection(
            name="incidents",
            metadata={"description": "Security incidents and threats"},
            embedding_function=default_ef
        )
        
        self.patterns_collection = self.client.get_or_create_collection(
            name="attack_patterns",
            metadata={"description": "Learned attack patterns"},
            embedding_function=default_ef
        )
        
        self.ioc_collection = self.client.get_or_create_collection(
            name="iocs",
            metadata={"description": "Indicators of Compromise"},
            embedding_function=default_ef
        )
        
        self.incident_counter = self._get_current_count()
    
    def _get_current_count(self) -> int:
        """Get current incident count from collection"""
        try:
            results = self.incidents_collection.get()
            return len(results['ids']) if results['ids'] else 0
        except:
            return 0
    
    def add_incident(self, incident: Dict[str, Any]):
        """Add new incident to vector memory"""
        incident_id = f"incident_{self.incident_counter + 1}"
        self.incident_counter += 1
        
        incident['id'] = incident_id
        incident['status'] = incident.get('status', 'active')
        incident['timestamp'] = incident.get('timestamp', datetime.now().isoformat())
        
        document_text = self._create_incident_document(incident)
        
        details = incident.get('details', {})
        
        self.incidents_collection.add(
            documents=[document_text],
            metadatas=[{
                'type': incident.get('type', 'unknown'),
                'severity': incident.get('severity', 'medium'),
                'timestamp': incident['timestamp'],
                'status': incident['status'],
                'description': incident.get('description', ''),
                'host': details.get('host', details.get('asset', 'unknown')),
                'details_json': json.dumps(details) if details else '{}'
            }],
            ids=[incident_id]
        )
        
        self._extract_and_store_iocs(incident, incident_id)
        
        return incident_id
    
    def _create_incident_document(self, incident: Dict[str, Any]) -> str:
        """Create searchable document from incident"""
        doc_parts = [
            f"Type: {incident.get('type', 'unknown')}",
            f"Severity: {incident.get('severity', 'medium')}",
            f"Description: {incident.get('description', '')}",
        ]
        
        details = incident.get('details', {})
        if isinstance(details, dict):
            if 'attack_type' in details:
                doc_parts.append(f"Attack: {details['attack_type']}")
            if 'mitre_technique' in details:
                doc_parts.append(f"MITRE: {details['mitre_technique']}")
            if 'host' in details:
                doc_parts.append(f"Host: {details['host']}")
            if 'source_ip' in details:
                doc_parts.append(f"Source IP: {details['source_ip']}")
        
        return " | ".join(doc_parts)
    
    def _extract_and_store_iocs(self, incident: Dict[str, Any], incident_id: str):
        """Extract and store Indicators of Compromise"""
        details = incident.get('details', {})
        iocs = []
        
        if isinstance(details, dict):
            if 'source_ip' in details and details['source_ip'] != 'unknown':
                iocs.append({
                    'type': 'ip_address',
                    'value': details['source_ip'],
                    'context': 'source'
                })
            
            if 'dest_ip' in details and details['dest_ip'] != 'unknown':
                iocs.append({
                    'type': 'ip_address',
                    'value': details['dest_ip'],
                    'context': 'destination'
                })
            
            if 'hash' in details:
                iocs.append({
                    'type': 'file_hash',
                    'value': details['hash'],
                    'context': 'malware'
                })
            
            if 'network_iocs' in details:
                network = details['network_iocs']
                if isinstance(network, dict):
                    for ip in network.get('ip_addresses', []):
                        iocs.append({
                            'type': 'ip_address',
                            'value': ip,
                            'context': 'c2_server'
                        })
                    for domain in network.get('domains', []):
                        iocs.append({
                            'type': 'domain',
                            'value': domain,
                            'context': 'c2_domain'
                        })
        
        for idx, ioc in enumerate(iocs):
            ioc_id = f"{incident_id}_ioc_{idx}"
            try:
                self.ioc_collection.add(
                    documents=[f"{ioc['type']}: {ioc['value']} ({ioc['context']})"],
                    metadatas=[{
                        'type': ioc['type'],
                        'value': ioc['value'],
                        'context': ioc['context'],
                        'incident_id': incident_id,
                        'timestamp': incident.get('timestamp', datetime.now().isoformat())
                    }],
                    ids=[ioc_id]
                )
            except:
                pass
    
    def get_all_incidents(self) -> List[Dict[str, Any]]:
        """Get all stored incidents"""
        try:
            results = self.incidents_collection.get()
            
            incidents = []
            for i, doc_id in enumerate(results['ids']):
                details_json = results['metadatas'][i].get('details_json', '{}')
                try:
                    details = json.loads(details_json) if details_json else {}
                except:
                    details = {}
                
                incident = {
                    'id': doc_id,
                    'type': results['metadatas'][i].get('type', 'unknown'),
                    'severity': results['metadatas'][i].get('severity', 'medium'),
                    'timestamp': results['metadatas'][i].get('timestamp', ''),
                    'status': results['metadatas'][i].get('status', 'active'),
                    'description': results['metadatas'][i].get('description', ''),
                    'details': details
                }
                incidents.append(incident)
            
            return sorted(incidents, key=lambda x: x.get('timestamp', ''), reverse=True)
        except:
            return []
    
    def get_active_threats(self) -> List[Dict[str, Any]]:
        """Get currently active threats"""
        all_incidents = self.get_all_incidents()
        active = [i for i in all_incidents if i.get('status') == 'active']
        return active[-10:]
    
    def search_similar_incidents(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Search for similar incidents using semantic similarity"""
        try:
            results = self.incidents_collection.query(
                query_texts=[query],
                n_results=limit
            )
            
            similar_incidents = []
            if results['ids']:
                for i, doc_id in enumerate(results['ids'][0]):
                    incident = {
                        'id': doc_id,
                        'type': results['metadatas'][0][i].get('type', 'unknown'),
                        'severity': results['metadatas'][0][i].get('severity', 'medium'),
                        'timestamp': results['metadatas'][0][i].get('timestamp', ''),
                        'description': results['documents'][0][i],
                        'similarity_score': 1.0 - results['distances'][0][i] if results.get('distances') else 0.0
                    }
                    similar_incidents.append(incident)
            
            return similar_incidents
        except Exception as e:
            print(f"Error searching incidents: {e}")
            return []
    
    def search_iocs(self, ioc_value: str, ioc_type: str = None) -> List[Dict[str, Any]]:
        """Search for IOCs by value or type"""
        try:
            where_filter = {}
            if ioc_type:
                where_filter['type'] = ioc_type
            
            results = self.ioc_collection.query(
                query_texts=[ioc_value],
                n_results=10,
                where=where_filter if where_filter else None
            )
            
            iocs = []
            if results['ids']:
                for i, ioc_id in enumerate(results['ids'][0]):
                    ioc = {
                        'id': ioc_id,
                        'type': results['metadatas'][0][i].get('type', 'unknown'),
                        'value': results['metadatas'][0][i].get('value', ''),
                        'context': results['metadatas'][0][i].get('context', ''),
                        'incident_id': results['metadatas'][0][i].get('incident_id', ''),
                        'timestamp': results['metadatas'][0][i].get('timestamp', ''),
                        'relevance': 1.0 - results['distances'][0][i] if results.get('distances') else 0.0
                    }
                    iocs.append(ioc)
            
            return iocs
        except Exception as e:
            print(f"Error searching IOCs: {e}")
            return []
    
    def add_attack_pattern(self, pattern: Dict[str, Any]):
        """Store learned attack pattern"""
        pattern_id = f"pattern_{pattern.get('name', 'unknown').replace(' ', '_')}_{int(datetime.now().timestamp())}"
        
        document_text = f"{pattern.get('name', 'Unknown Pattern')} - {pattern.get('description', '')} - Indicators: {', '.join(pattern.get('indicators', []))}"
        
        try:
            self.patterns_collection.add(
                documents=[document_text],
                metadatas=[{
                    'name': pattern.get('name', 'Unknown'),
                    'mitre_id': pattern.get('mitre_id', 'unknown'),
                    'severity': pattern.get('severity', 'medium'),
                    'frequency': pattern.get('frequency', 1)
                }],
                ids=[pattern_id]
            )
        except:
            pass
    
    def get_learned_patterns(self) -> Dict[str, Any]:
        """Get learned attack patterns"""
        try:
            results = self.patterns_collection.get()
            
            patterns = []
            for i, pattern_id in enumerate(results['ids']):
                pattern = {
                    'name': results['metadatas'][i].get('name', 'Unknown'),
                    'frequency': results['metadatas'][i].get('frequency', 0),
                    'mitre_id': results['metadatas'][i].get('mitre_id', 'unknown'),
                    'severity': results['metadatas'][i].get('severity', 'medium')
                }
                patterns.append(pattern)
            
            return {
                'attack_patterns': patterns,
                'total_patterns': len(patterns),
                'accuracy_improvement': min(25.0, len(patterns) * 2.5)
            }
        except:
            return {
                'attack_patterns': [],
                'total_patterns': 0,
                'accuracy_improvement': 0.0
            }
    
    def get_analytics(self) -> Dict[str, Any]:
        """Get analytics about stored memory"""
        all_incidents = self.get_all_incidents()
        
        if not all_incidents:
            return {
                'total_events': 0,
                'unique_threats': 0,
                'learning_rate': 0,
                'incident_distribution': [],
                'time_series': []
            }
        
        type_counts = {}
        for incident in all_incidents:
            itype = incident.get('type', 'unknown')
            type_counts[itype] = type_counts.get(itype, 0) + 1
        
        return {
            'total_events': len(all_incidents),
            'unique_threats': len(type_counts),
            'learning_rate': min(1.0, len(all_incidents) / 100),
            'incident_distribution': [
                {'type': k, 'count': v} for k, v in type_counts.items()
            ],
            'time_series': []
        }
    
    def get_incidents_by_type(self, incident_type: str) -> List[Dict[str, Any]]:
        """Get incidents of specific type"""
        all_incidents = self.get_all_incidents()
        return [i for i in all_incidents if i.get('type') == incident_type]
    
    def get_incidents_by_host(self, host: str) -> List[Dict[str, Any]]:
        """Get incidents for specific host (requires full document retrieval)"""
        results = self.incidents_collection.get()
        
        host_incidents = []
        for i, doc in enumerate(results['documents']):
            if host in doc:
                incident = {
                    'id': results['ids'][i],
                    'type': results['metadatas'][i].get('type', 'unknown'),
                    'severity': results['metadatas'][i].get('severity', 'medium'),
                    'timestamp': results['metadatas'][i].get('timestamp', ''),
                    'description': doc
                }
                host_incidents.append(incident)
        
        return host_incidents
