"""
Visualization Utilities - Create security-focused charts and graphs
"""

import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
import random

def create_threat_timeline(incidents):
    """Create timeline visualization of threats"""
    
    if not incidents:
        # Create empty chart with message
        fig = go.Figure()
        fig.add_annotation(
            text="No threat data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=14, color="gray")
        )
        fig.update_layout(
            title="Threat Detection Timeline",
            height=300,
            template="plotly_dark"
        )
        return fig
    
    # Process incidents for timeline
    timeline_data = []
    for incident in incidents[-20:]:  # Last 20 incidents
        timeline_data.append({
            'timestamp': incident.get('timestamp', datetime.now().isoformat()),
            'type': incident.get('type', 'unknown'),
            'severity': incident.get('severity', 'medium'),
            'description': incident.get('description', '')[:50]
        })
    
    df = pd.DataFrame(timeline_data)
    
    # Color mapping for severity
    color_map = {
        'critical': '#FF4B4B',
        'high': '#FFA500',
        'medium': '#FFD700',
        'low': '#90EE90'
    }
    
    df['color'] = df['severity'].map(color_map)
    
    fig = go.Figure()
    
    for severity in ['critical', 'high', 'medium', 'low']:
        severity_data = df[df['severity'] == severity]
        if not severity_data.empty:
            fig.add_trace(go.Scatter(
                x=severity_data['timestamp'],
                y=severity_data['type'],
                mode='markers',
                name=severity.title(),
                marker=dict(
                    size=12,
                    color=color_map[severity],
                    line=dict(width=1, color='white')
                ),
                text=severity_data['description'],
                hovertemplate='<b>%{y}</b><br>Time: %{x}<br>%{text}<extra></extra>'
            ))
    
    fig.update_layout(
        title="Threat Detection Timeline",
        xaxis_title="Time",
        yaxis_title="Threat Type",
        height=400,
        template="plotly_dark",
        hovermode='closest'
    )
    
    return fig

def create_risk_heatmap(risk_engine):
    """Create risk heatmap for assets"""
    
    asset_risks = risk_engine.get_asset_risks()
    
    if not asset_risks:
        fig = go.Figure()
        fig.add_annotation(
            text="No asset risk data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False
        )
        return fig
    
    # Prepare data for heatmap
    assets = [a['name'] for a in asset_risks]
    risk_scores = [a['risk_score'] for a in asset_risks]
    vulnerabilities = [a['vulnerabilities'] for a in asset_risks]
    
    # Create matrix for heatmap
    matrix_data = []
    categories = ['Risk Score', 'Vulnerabilities', 'Active Threats']
    
    for asset in asset_risks:
        matrix_data.append([
            asset['risk_score'],
            asset['vulnerabilities'],
            asset['active_threats']
        ])
    
    fig = go.Figure(data=go.Heatmap(
        z=list(zip(*matrix_data)),  # Transpose
        x=assets,
        y=categories,
        colorscale='Reds',
        text=list(zip(*matrix_data)),
        texttemplate='%{text}',
        textfont={"size": 10},
        hovertemplate='Asset: %{x}<br>Metric: %{y}<br>Value: %{z}<extra></extra>'
    ))
    
    fig.update_layout(
        title="Asset Risk Heatmap",
        height=300,
        template="plotly_dark",
        xaxis={'side': 'bottom'},
        yaxis={'side': 'left'}
    )
    
    return fig

def create_attack_graph(graph_data):
    """Create network graph visualization of threat correlations"""
    
    nodes = graph_data.get('nodes', [])
    edges = graph_data.get('edges', [])
    
    if not nodes:
        fig = go.Figure()
        fig.add_annotation(
            text="No correlation data available",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False
        )
        return fig
    
    # Create node positions (circular layout)
    import math
    n = len(nodes)
    node_positions = {}
    for i, node in enumerate(nodes):
        angle = 2 * math.pi * i / n
        node_positions[node['id']] = (math.cos(angle), math.sin(angle))
    
    # Create edge traces
    edge_traces = []
    for edge in edges:
        x0, y0 = node_positions[edge['source']]
        x1, y1 = node_positions[edge['target']]
        
        color_map = {
            'critical': '#FF4B4B',
            'high': '#FFA500',
            'medium': '#FFD700',
            'low': '#90EE90'
        }
        
        edge_trace = go.Scatter(
            x=[x0, x1, None],
            y=[y0, y1, None],
            mode='lines',
            line=dict(
                width=2,
                color=color_map.get(edge.get('severity', 'medium'), '#888')
            ),
            hoverinfo='none',
            showlegend=False
        )
        edge_traces.append(edge_trace)
    
    # Create node trace
    node_x = [node_positions[node['id']][0] for node in nodes]
    node_y = [node_positions[node['id']][1] for node in nodes]
    node_text = [node['label'] for node in nodes]
    node_colors = ['#FF6B6B' if node['type'] == 'threat_type' else '#4ECDC4' for node in nodes]
    
    node_trace = go.Scatter(
        x=node_x,
        y=node_y,
        mode='markers+text',
        marker=dict(
            size=20,
            color=node_colors,
            line=dict(width=2, color='white')
        ),
        text=node_text,
        textposition="top center",
        hovertemplate='<b>%{text}</b><extra></extra>',
        showlegend=False
    )
    
    # Create figure
    fig = go.Figure(data=edge_traces + [node_trace])
    
    fig.update_layout(
        title="Threat Correlation Graph",
        showlegend=False,
        hovermode='closest',
        height=500,
        template="plotly_dark",
        xaxis=dict(showgrid=False, zeroline=False, showticklabels=False),
        yaxis=dict(showgrid=False, zeroline=False, showticklabels=False)
    )
    
    return fig
