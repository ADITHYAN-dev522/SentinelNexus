"""
Log Parser Utility - Parse security logs from multiple formats
Supports Zeek, Suricata, Sysmon, and generic formats
"""

import json
import re
from datetime import datetime
from typing import List, Dict, Any

class LogParser:
    def __init__(self):
        self.supported_formats = ['zeek', 'suricata', 'sysmon', 'generic']
    
    def parse_log_file(self, file_content: str, log_format: str = 'generic') -> List[Dict[str, Any]]:
        """Parse log file content based on format"""
        
        if log_format == 'zeek':
            return self._parse_zeek_logs(file_content)
        elif log_format == 'suricata':
            return self._parse_suricata_logs(file_content)
        elif log_format == 'sysmon':
            return self._parse_sysmon_logs(file_content)
        else:
            return self._parse_generic_logs(file_content)
    
    def _parse_zeek_logs(self, content: str) -> List[Dict[str, Any]]:
        """Parse Zeek/Bro log format"""
        events = []
        lines = content.strip().split('\n')
        
        headers = []
        for line in lines:
            if line.startswith('#separator'):
                continue
            elif line.startswith('#fields'):
                headers = line.replace('#fields\t', '').split('\t')
            elif line.startswith('#'):
                continue
            elif headers and line.strip():
                values = line.split('\t')
                event = dict(zip(headers, values))
                
                parsed_event = {
                    'timestamp': event.get('ts', datetime.now().isoformat()),
                    'source_ip': event.get('id.orig_h', 'unknown'),
                    'dest_ip': event.get('id.resp_h', 'unknown'),
                    'source_port': event.get('id.orig_p', '0'),
                    'dest_port': event.get('id.resp_p', '0'),
                    'protocol': event.get('proto', 'unknown'),
                    'service': event.get('service', 'unknown'),
                    'event_type': 'network_connection',
                    'raw_data': event
                }
                
                if self._is_suspicious_zeek(event):
                    parsed_event['suspicious'] = True
                    parsed_event['reason'] = self._get_zeek_suspicion_reason(event)
                
                events.append(parsed_event)
        
        return events
    
    def _parse_suricata_logs(self, content: str) -> List[Dict[str, Any]]:
        """Parse Suricata JSON log format"""
        events = []
        lines = content.strip().split('\n')
        
        for line in lines:
            if not line.strip():
                continue
            
            try:
                log_entry = json.loads(line)
                
                parsed_event = {
                    'timestamp': log_entry.get('timestamp', datetime.now().isoformat()),
                    'source_ip': log_entry.get('src_ip', 'unknown'),
                    'dest_ip': log_entry.get('dest_ip', 'unknown'),
                    'source_port': str(log_entry.get('src_port', 0)),
                    'dest_port': str(log_entry.get('dest_port', 0)),
                    'protocol': log_entry.get('proto', 'unknown'),
                    'event_type': log_entry.get('event_type', 'unknown'),
                    'raw_data': log_entry
                }
                
                if log_entry.get('event_type') == 'alert':
                    alert = log_entry.get('alert', {})
                    parsed_event['alert'] = {
                        'signature': alert.get('signature', 'Unknown'),
                        'category': alert.get('category', 'Unknown'),
                        'severity': alert.get('severity', 3)
                    }
                    parsed_event['suspicious'] = True
                    parsed_event['reason'] = alert.get('signature', 'Alert triggered')
                
                events.append(parsed_event)
                
            except json.JSONDecodeError:
                continue
        
        return events
    
    def _parse_sysmon_logs(self, content: str) -> List[Dict[str, Any]]:
        """Parse Windows Sysmon log format"""
        events = []
        lines = content.strip().split('\n')
        
        current_event = {}
        
        for line in lines:
            if line.startswith('Event ID:'):
                if current_event:
                    events.append(self._process_sysmon_event(current_event))
                    current_event = {}
                current_event['event_id'] = line.split(':')[1].strip()
            elif ':' in line and current_event:
                key, value = line.split(':', 1)
                current_event[key.strip()] = value.strip()
        
        if current_event:
            events.append(self._process_sysmon_event(current_event))
        
        return events
    
    def _parse_generic_logs(self, content: str) -> List[Dict[str, Any]]:
        """Parse generic log format"""
        events = []
        lines = content.strip().split('\n')
        
        for i, line in enumerate(lines):
            if not line.strip():
                continue
            
            event = {
                'line_number': i + 1,
                'timestamp': datetime.now().isoformat(),
                'message': line,
                'event_type': 'generic_log'
            }
            
            if self._is_suspicious_generic(line):
                event['suspicious'] = True
                event['reason'] = self._get_generic_suspicion_reason(line)
            
            events.append(event)
        
        return events
    
    def _process_sysmon_event(self, event_data: Dict[str, str]) -> Dict[str, Any]:
        """Process Sysmon event data"""
        event_id = event_data.get('event_id', 'unknown')
        
        parsed = {
            'timestamp': event_data.get('UtcTime', datetime.now().isoformat()),
            'event_type': f'sysmon_event_{event_id}',
            'event_id': event_id,
            'computer': event_data.get('Computer', 'unknown'),
            'user': event_data.get('User', 'unknown'),
            'raw_data': event_data
        }
        
        if event_id == '1':
            parsed['event_type'] = 'process_creation'
            parsed['process'] = event_data.get('Image', 'unknown')
            parsed['command_line'] = event_data.get('CommandLine', '')
            parsed['parent_process'] = event_data.get('ParentImage', 'unknown')
        elif event_id == '3':
            parsed['event_type'] = 'network_connection'
            parsed['source_ip'] = event_data.get('SourceIp', 'unknown')
            parsed['dest_ip'] = event_data.get('DestinationIp', 'unknown')
            parsed['dest_port'] = event_data.get('DestinationPort', '0')
        elif event_id == '10':
            parsed['event_type'] = 'process_access'
            parsed['target_process'] = event_data.get('TargetImage', 'unknown')
        
        if self._is_suspicious_sysmon(event_data):
            parsed['suspicious'] = True
            parsed['reason'] = self._get_sysmon_suspicion_reason(event_data)
        
        return parsed
    
    def _is_suspicious_zeek(self, event: Dict[str, str]) -> bool:
        """Check if Zeek event is suspicious"""
        suspicious_ports = ['22', '23', '445', '3389', '1433', '3306']
        service = event.get('service', '')
        dest_port = event.get('id.resp_p', '')
        
        if dest_port in suspicious_ports:
            return True
        if 'error' in service.lower() or 'failed' in service.lower():
            return True
        
        return False
    
    def _is_suspicious_sysmon(self, event: Dict[str, str]) -> bool:
        """Check if Sysmon event is suspicious"""
        suspicious_keywords = [
            'powershell', 'cmd.exe', 'wscript', 'cscript', 
            'mimikatz', 'psexec', 'procdump', 'lsass'
        ]
        
        command_line = event.get('CommandLine', '').lower()
        image = event.get('Image', '').lower()
        target = event.get('TargetImage', '').lower()
        
        for keyword in suspicious_keywords:
            if keyword in command_line or keyword in image or keyword in target:
                return True
        
        return False
    
    def _is_suspicious_generic(self, line: str) -> bool:
        """Check if generic log line is suspicious"""
        suspicious_patterns = [
            r'failed.*login', r'unauthorized', r'denied', r'error',
            r'attack', r'exploit', r'malware', r'virus', r'intrusion'
        ]
        
        line_lower = line.lower()
        for pattern in suspicious_patterns:
            if re.search(pattern, line_lower):
                return True
        
        return False
    
    def _get_zeek_suspicion_reason(self, event: Dict[str, str]) -> str:
        """Get reason for Zeek suspicion"""
        dest_port = event.get('id.resp_p', '')
        if dest_port in ['22', '23']:
            return f'Connection to sensitive port {dest_port}'
        elif dest_port in ['445', '3389']:
            return f'Potential lateral movement via port {dest_port}'
        elif dest_port in ['1433', '3306']:
            return f'Database connection on port {dest_port}'
        return 'Suspicious network activity detected'
    
    def _get_sysmon_suspicion_reason(self, event: Dict[str, str]) -> str:
        """Get reason for Sysmon suspicion"""
        command_line = event.get('CommandLine', '').lower()
        
        if 'powershell' in command_line:
            return 'PowerShell execution detected'
        elif 'mimikatz' in command_line or 'lsass' in command_line:
            return 'Potential credential dumping activity'
        elif 'psexec' in command_line:
            return 'Potential lateral movement tool detected'
        
        return 'Suspicious process activity detected'
    
    def _get_generic_suspicion_reason(self, line: str) -> str:
        """Get reason for generic log suspicion"""
        line_lower = line.lower()
        
        if 'failed' in line_lower and 'login' in line_lower:
            return 'Failed login attempt detected'
        elif 'unauthorized' in line_lower:
            return 'Unauthorized access attempt'
        elif 'denied' in line_lower:
            return 'Access denied event'
        elif any(word in line_lower for word in ['attack', 'exploit']):
            return 'Potential attack detected'
        elif any(word in line_lower for word in ['malware', 'virus']):
            return 'Malware activity detected'
        
        return 'Suspicious activity detected'
    
    def extract_threats(self, parsed_events: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Extract suspicious events as threats"""
        threats = []
        
        for event in parsed_events:
            if event.get('suspicious', False):
                threat = {
                    'type': 'threat_detection',
                    'severity': self._calculate_severity(event),
                    'description': event.get('reason', 'Suspicious activity detected'),
                    'timestamp': event.get('timestamp', datetime.now().isoformat()),
                    'source_ip': event.get('source_ip', 'unknown'),
                    'dest_ip': event.get('dest_ip', 'unknown'),
                    'event_type': event.get('event_type', 'unknown'),
                    'details': event
                }
                threats.append(threat)
        
        return threats
    
    def _calculate_severity(self, event: Dict[str, Any]) -> str:
        """Calculate threat severity"""
        reason = event.get('reason', '').lower()
        
        if any(keyword in reason for keyword in ['credential', 'mimikatz', 'lsass', 'exploit']):
            return 'critical'
        elif any(keyword in reason for keyword in ['lateral', 'psexec', 'attack', 'malware']):
            return 'high'
        elif any(keyword in reason for keyword in ['unauthorized', 'failed', 'denied']):
            return 'medium'
        else:
            return 'low'
