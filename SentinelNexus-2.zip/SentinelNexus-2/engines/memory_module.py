"""
Memory Module - SOC Memory System
Stores and retrieves historical security incidents for learning
"""

import json
import os
from datetime import datetime
from pathlib import Path

class MemoryModule:
    def __init__(self):
        self.incidents_file = 'data/incidents.json'
        self._ensure_data_directory()
        self.incidents = self._load_incidents()
    
    def _ensure_data_directory(self):
        """Ensure data directory exists"""
        Path('data').mkdir(exist_ok=True)
        
        # Initialize incidents file if it doesn't exist
        if not os.path.exists(self.incidents_file):
            with open(self.incidents_file, 'w') as f:
                json.dump([], f)
    
    def _load_incidents(self):
        """Load incidents from file"""
        try:
            with open(self.incidents_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []
    
    def _save_incidents(self):
        """Save incidents to file"""
        with open(self.incidents_file, 'w') as f:
            json.dump(self.incidents, f, indent=2)
    
    def add_incident(self, incident):
        """Add new incident to memory"""
        incident['id'] = len(self.incidents) + 1
        incident['status'] = incident.get('status', 'active')
        self.incidents.append(incident)
        self._save_incidents()
    
    def get_all_incidents(self):
        """Get all stored incidents"""
        return self.incidents
    
    def get_active_threats(self):
        """Get currently active threats"""
        return [i for i in self.incidents if i.get('status') == 'active'][-10:]
    
    def get_incidents_by_type(self, incident_type):
        """Get incidents of specific type"""
        return [i for i in self.incidents if i.get('type') == incident_type]
    
    def get_incidents_by_host(self, host):
        """Get incidents for specific host"""
        return [
            i for i in self.incidents 
            if i.get('details', {}).get('host') == host 
            or i.get('details', {}).get('asset') == host
        ]
    
    def get_learned_patterns(self):
        """Get learned attack patterns"""
        
        # Analyze incidents for patterns
        attack_patterns = {}
        
        for incident in self.incidents:
            incident_type = incident.get('type')
            if incident_type not in attack_patterns:
                attack_patterns[incident_type] = {
                    'name': incident_type.replace('_', ' ').title(),
                    'frequency': 0,
                    'last_seen': incident.get('timestamp'),
                    'recommendation': self._generate_recommendation(incident_type)
                }
            attack_patterns[incident_type]['frequency'] += 1
        
        # Calculate false positive reduction
        total_incidents = len(self.incidents)
        false_positives = sum(1 for i in self.incidents if i.get('false_positive', False))
        fp_rate = (false_positives / total_incidents * 100) if total_incidents > 0 else 0
        
        return {
            'attack_patterns': list(attack_patterns.values()),
            'false_positives_count': false_positives,
            'accuracy_improvement': max(0, 15 - fp_rate)  # Improvement from baseline
        }
    
    def get_analytics(self):
        """Get analytics about stored memory"""
        
        if not self.incidents:
            return {
                'total_events': 0,
                'unique_threats': 0,
                'learning_rate': 0,
                'incident_distribution': [],
                'time_series': []
            }
        
        # Count by type
        type_counts = {}
        for incident in self.incidents:
            itype = incident.get('type', 'unknown')
            type_counts[itype] = type_counts.get(itype, 0) + 1
        
        # Time series (simplified)
        time_series = []
        dates = {}
        for incident in self.incidents:
            date = incident.get('timestamp', '')[:10]  # Get date part
            dates[date] = dates.get(date, 0) + 1
        
        for date, count in sorted(dates.items()):
            time_series.append({'date': date, 'count': count})
        
        return {
            'total_events': len(self.incidents),
            'unique_threats': len(set(i.get('type') for i in self.incidents)),
            'learning_rate': min(1.0, len(self.incidents) / 100),  # Improves with more data
            'incident_distribution': [
                {'type': k, 'count': v} for k, v in type_counts.items()
            ],
            'time_series': time_series[-30:]  # Last 30 days
        }
    
    def _generate_recommendation(self, incident_type):
        """Generate recommendation based on incident type"""
        recommendations = {
            'vulnerability': 'Implement automated patch management',
            'threat_detection': 'Enhance monitoring rules and signatures',
            'malware_detection': 'Update antivirus definitions and enable sandboxing'
        }
        return recommendations.get(incident_type, 'Review and update security policies')
