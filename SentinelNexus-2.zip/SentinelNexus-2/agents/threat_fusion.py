"""
ThreatFusion Brain - Intelligence Aggregation & Threat Forecasting
Correlates threat data and predicts attack chains
"""

import random
from datetime import datetime
import networkx as nx

class ThreatFusionBrain:
    def __init__(self, memory_module):
        self.memory = memory_module
        self.graph = nx.DiGraph()
        
    def generate_correlation_graph(self):
        """Generate threat correlation graph with enhanced analytics"""
        
        # Get all incidents from memory
        incidents = self.memory.get_all_incidents()
        
        # Build graph
        self.graph.clear()
        
        # Add nodes for different threat types
        threat_types = set(i['type'] for i in incidents)
        for threat_type in threat_types:
            self.graph.add_node(threat_type, node_type='threat_type')
        
        # Add nodes for assets/hosts
        assets = set()
        for incident in incidents:
            details = incident.get('details', {})
            asset = details.get('asset') or details.get('host')
            if asset:
                assets.add(asset)
                self.graph.add_node(asset, node_type='asset')
        
        # Add edges for correlations with weight tracking
        edge_weights = {}
        for incident in incidents:
            threat_type = incident['type']
            details = incident.get('details', {})
            asset = details.get('asset') or details.get('host')
            
            if asset:
                edge_key = (threat_type, asset)
                if edge_key not in edge_weights:
                    edge_weights[edge_key] = {
                        'count': 0,
                        'severity': incident.get('severity', 'medium')
                    }
                edge_weights[edge_key]['count'] += 1
        
        # Add weighted edges
        for (source, target), data in edge_weights.items():
            self.graph.add_edge(source, target, 
                               weight=data['count'],
                               severity=data['severity'])
        
        # Calculate centrality metrics if graph is non-empty
        centrality = {}
        betweenness = {}
        
        if len(self.graph.nodes()) > 0 and len(self.graph.edges()) > 0:
            try:
                centrality = nx.degree_centrality(self.graph)
                betweenness = nx.betweenness_centrality(self.graph)
            except:
                centrality = {node: 0 for node in self.graph.nodes()}
                betweenness = {node: 0 for node in self.graph.nodes()}
        
        # Convert to format suitable for visualization
        return {
            'nodes': [
                {
                    'id': node,
                    'type': self.graph.nodes[node].get('node_type', 'unknown'),
                    'label': node,
                    'centrality': centrality.get(node, 0),
                    'betweenness': betweenness.get(node, 0),
                    'degree': self.graph.degree(node)
                }
                for node in self.graph.nodes()
            ],
            'edges': [
                {
                    'source': edge[0],
                    'target': edge[1],
                    'severity': self.graph.edges[edge].get('severity', 'medium'),
                    'weight': self.graph.edges[edge].get('weight', 1)
                }
                for edge in self.graph.edges()
            ],
            'analytics': {
                'total_nodes': len(self.graph.nodes()),
                'total_edges': len(self.graph.edges()),
                'most_central': max(centrality.items(), key=lambda x: x[1])[0] if centrality else None,
                'most_connected': max(dict(self.graph.degree()).items(), key=lambda x: x[1])[0] if self.graph.degree() else None
            }
        }
    
    def predict_attack_chain(self):
        """Predict likely attack progression using MITRE ATT&CK"""
        
        # Common attack chains based on MITRE ATT&CK
        attack_chains = [
            {
                'name': 'Ransomware Attack Chain',
                'steps': [
                    {'technique': 'T1566 - Phishing', 'description': 'Initial compromise via phishing email', 'probability': 0.85},
                    {'technique': 'T1204 - User Execution', 'description': 'User opens malicious attachment', 'probability': 0.75},
                    {'technique': 'T1055 - Process Injection', 'description': 'Malware injects into legitimate processes', 'probability': 0.70},
                    {'technique': 'T1003 - Credential Dumping', 'description': 'Harvest credentials from memory', 'probability': 0.65},
                    {'technique': 'T1021 - Lateral Movement', 'description': 'Move to other systems in network', 'probability': 0.60},
                    {'technique': 'T1486 - Data Encryption', 'description': 'Encrypt files for ransom', 'probability': 0.80}
                ]
            },
            {
                'name': 'APT Exfiltration Chain',
                'steps': [
                    {'technique': 'T1190 - Exploit Public-Facing Application', 'description': 'Exploit web application vulnerability', 'probability': 0.75},
                    {'technique': 'T1505 - Web Shell', 'description': 'Deploy web shell for persistence', 'probability': 0.70},
                    {'technique': 'T1082 - System Discovery', 'description': 'Enumerate system information', 'probability': 0.85},
                    {'technique': 'T1083 - File Discovery', 'description': 'Search for sensitive data', 'probability': 0.80},
                    {'technique': 'T1560 - Archive Collected Data', 'description': 'Compress data for exfiltration', 'probability': 0.75},
                    {'technique': 'T1041 - Exfiltration Over C2', 'description': 'Exfiltrate data via command and control', 'probability': 0.70}
                ]
            },
            {
                'name': 'Insider Threat Chain',
                'steps': [
                    {'technique': 'T1078 - Valid Accounts', 'description': 'Use legitimate credentials', 'probability': 0.90},
                    {'technique': 'T1213 - Data from Information Repositories', 'description': 'Access sensitive repositories', 'probability': 0.85},
                    {'technique': 'T1114 - Email Collection', 'description': 'Harvest email data', 'probability': 0.75},
                    {'technique': 'T1020 - Automated Exfiltration', 'description': 'Automate data collection', 'probability': 0.70},
                    {'technique': 'T1567 - Exfiltration to Cloud', 'description': 'Upload to external cloud storage', 'probability': 0.80}
                ]
            }
        ]
        
        # Select most likely chain based on recent incidents
        selected_chain = random.choice(attack_chains)
        
        return selected_chain['steps']
    
    def get_threat_intelligence(self):
        """Get aggregated threat intelligence"""
        
        incidents = self.memory.get_all_incidents()
        
        # Aggregate by type
        by_type = {}
        for incident in incidents:
            itype = incident['type']
            by_type[itype] = by_type.get(itype, 0) + 1
        
        # Aggregate by severity
        by_severity = {}
        for incident in incidents:
            severity = incident.get('severity', 'unknown')
            by_severity[severity] = by_severity.get(severity, 0) + 1
        
        return {
            'total_incidents': len(incidents),
            'by_type': by_type,
            'by_severity': by_severity,
            'trends': self._analyze_trends(incidents)
        }
    
    def _analyze_trends(self, incidents):
        """Analyze threat trends"""
        
        if len(incidents) < 2:
            return {'trend': 'stable', 'change': 0}
        
        # Simple trend analysis based on recent vs older incidents
        recent_count = sum(1 for i in incidents[-5:])
        older_count = sum(1 for i in incidents[:-5]) if len(incidents) > 5 else 0
        
        if recent_count > older_count * 1.2:
            return {'trend': 'increasing', 'change': 20}
        elif recent_count < older_count * 0.8:
            return {'trend': 'decreasing', 'change': -20}
        else:
            return {'trend': 'stable', 'change': 0}
