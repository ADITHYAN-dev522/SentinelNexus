"""
ThreatSentinel Agent - Threat Detection via Logs & Events
Analyzes logs for threats and maps to MITRE ATT&CK framework
"""

import random
from datetime import datetime
from utils.mitre_attack import MitreAttack
from utils.log_parser import LogParser

class ThreatSentinelAgent:
    def __init__(self, memory_module):
        self.memory = memory_module
        self.mitre = MitreAttack()
        self.log_parser = LogParser()
        
        # Simulated log patterns that indicate threats
        self.threat_patterns = [
            {
                'name': 'Credential Dumping',
                'mitre_id': 'T1003',
                'severity': 'critical',
                'indicators': ['lsass.exe access', 'mimikatz', 'procdump']
            },
            {
                'name': 'Lateral Movement',
                'mitre_id': 'T1021',
                'severity': 'high',
                'indicators': ['psexec', 'wmic', 'remote desktop']
            },
            {
                'name': 'Data Exfiltration',
                'mitre_id': 'T1041',
                'severity': 'critical',
                'indicators': ['large outbound transfer', 'unusual FTP', 'DNS tunneling']
            },
            {
                'name': 'Privilege Escalation',
                'mitre_id': 'T1068',
                'severity': 'high',
                'indicators': ['exploit attempt', 'UAC bypass', 'token manipulation']
            },
            {
                'name': 'Persistence Mechanism',
                'mitre_id': 'T1547',
                'severity': 'medium',
                'indicators': ['registry modification', 'scheduled task', 'startup folder']
            },
            {
                'name': 'Defense Evasion',
                'mitre_id': 'T1562',
                'severity': 'high',
                'indicators': ['antivirus disabled', 'log deletion', 'process injection']
            }
        ]
    
    def analyze_logs(self):
        """Analyze system logs for threats"""
        
        detections = []
        
        # Simulate log analysis with realistic threat detection
        num_threats = random.randint(2, 5)
        
        for _ in range(num_threats):
            pattern = random.choice(self.threat_patterns)
            
            # Get MITRE ATT&CK details
            mitre_info = self.mitre.get_technique_info(pattern['mitre_id'])
            
            detection = {
                'attack_type': pattern['name'],
                'mitre_technique': f"{pattern['mitre_id']} - {mitre_info['name']}",
                'severity': pattern['severity'],
                'description': mitre_info['description'],
                'confidence': random.uniform(0.75, 0.98),
                'host': f"HOST-{random.randint(100, 999)}",
                'timestamp': datetime.now().isoformat(),
                'indicators': random.sample(pattern['indicators'], k=min(2, len(pattern['indicators']))),
                'tactics': mitre_info['tactics']
            }
            
            detections.append(detection)
            
            # Store in memory
            self.memory.add_incident({
                'type': 'threat_detection',
                'severity': pattern['severity'],
                'description': f"Detected {pattern['name']} on {detection['host']}",
                'timestamp': datetime.now().isoformat(),
                'details': detection
            })
        
        return detections
    
    def analyze_log_file(self, log_content: str, log_format: str = 'generic'):
        """Analyze uploaded log file for threats"""
        
        parsed_events = self.log_parser.parse_log_file(log_content, log_format)
        threats = self.log_parser.extract_threats(parsed_events)
        
        detections = []
        
        for threat in threats:
            mitre_id = self._map_event_to_mitre(threat['event_type'], threat.get('reason', ''))
            mitre_info = self.mitre.get_technique_info(mitre_id)
            
            detection = {
                'attack_type': threat.get('description', 'Unknown Threat'),
                'mitre_technique': f"{mitre_id} - {mitre_info['name']}",
                'severity': threat['severity'],
                'description': threat.get('description', ''),
                'confidence': 0.92,
                'host': threat.get('source_ip', 'unknown'),
                'timestamp': threat.get('timestamp', datetime.now().isoformat()),
                'indicators': [threat.get('event_type', 'unknown')],
                'tactics': mitre_info['tactics']
            }
            
            detections.append(detection)
            
            self.memory.add_incident({
                'type': 'threat_detection',
                'severity': threat['severity'],
                'description': f"Log analysis detected: {threat.get('description', 'Unknown')}",
                'timestamp': threat.get('timestamp', datetime.now().isoformat()),
                'details': detection
            })
        
        return detections
    
    def _map_event_to_mitre(self, event_type: str, reason: str) -> str:
        """Map event type and reason to MITRE ATT&CK technique"""
        reason_lower = reason.lower()
        
        if 'credential' in reason_lower or 'mimikatz' in reason_lower or 'lsass' in reason_lower:
            return 'T1003'
        elif 'lateral' in reason_lower or 'psexec' in reason_lower:
            return 'T1021'
        elif 'powershell' in reason_lower:
            return 'T1059'
        elif 'failed login' in reason_lower:
            return 'T1110'
        elif 'malware' in reason_lower:
            return 'T1204'
        elif 'network' in event_type.lower():
            return 'T1071'
        else:
            return 'T1078'
    
    def get_attack_timeline(self, host):
        """Get chronological attack timeline for a specific host"""
        incidents = self.memory.get_incidents_by_host(host)
        
        timeline = []
        for incident in incidents:
            timeline.append({
                'timestamp': incident['timestamp'],
                'event': incident['description'],
                'severity': incident['severity']
            })
        
        return sorted(timeline, key=lambda x: x['timestamp'])
