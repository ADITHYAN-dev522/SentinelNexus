import React from 'react';
import { Globe, Users, Target, MapPin, Hash } from 'lucide-react';

const ThreatIntel = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg text-center">
        <p className="text-gray-400">IOCs Collected</p>
        <p className="text-2xl font-bold text-white">1,247</p>
      </div>
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg text-center">
        <p className="text-gray-400">Threat Actors</p>
        <p className="text-2xl font-bold text-white">87</p>
      </div>
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg text-center">
        <p className="text-gray-400">Campaigns</p>
        <p className="text-2xl font-bold text-white">34</p>
      </div>
    </div>

    <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
      <h3 className="text-xl text-white mb-4 flex items-center"><Globe className="mr-2 text-green-400" /> Geographic Threats</h3>
      <div className="h-48 bg-gray-700 flex items-center justify-center rounded-lg">
        <MapPin className="text-gray-400" size={32} />
      </div>
    </div>
  </div>
);

export default ThreatIntel;