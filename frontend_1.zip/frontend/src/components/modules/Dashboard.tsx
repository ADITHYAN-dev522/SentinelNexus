import React, { useState } from 'react';
import { AlertTriangle, Activity, Shield, Target, RefreshCw, Users, BarChart3, Wifi, WifiOff, Clock } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, CartesianGrid, XAxis, YAxis, Tooltip } from 'recharts';

const Dashboard = ({ setSelectedAlert }) => {
  const alerts = [
    { id: 1, type: 'critical', title: 'APT Detected', source: 'ThreatIntel', time: '2 min ago', details: 'Lazarus indicators found.', location: 'Server Room A', affected_systems: 3, confidence: 95 },
    { id: 2, type: 'high', title: 'Ransomware Signature Match', source: 'MalwareAgent', time: '5 min ago', details: 'REvil ransomware patterns.', location: 'Finance Dept.', affected_systems: 1, confidence: 88 }
  ];

  const threatData = [
    { time: '00:00', threats: 12, blocked: 10 },
    { time: '04:00', threats: 19, blocked: 16 },
    { time: '08:00', threats: 35, blocked: 28 },
    { time: '12:00', threats: 45, blocked: 41 },
    { time: '16:00', threats: 52, blocked: 48 }
  ];

  const agentStatus = [
    { name: 'VulnScanner', status: 'online', lastScan: '2 min ago', threats: 23 },
    { name: 'MalwareAgent', status: 'online', lastScan: '1 min ago', threats: 5 },
    { name: 'ThreatIntel', status: 'online', lastScan: '30 sec ago', threats: 12 },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
            <Target className="mr-2 text-red-400" size={20} /> Threat Level
          </h3>
          <div className="text-center text-red-400 text-2xl font-bold">75% HIGH</div>
        </div>
        <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center justify-between">
            <Activity className="mr-2 text-green-400" size={20} /> System Health
            <RefreshCw size={16} className="text-gray-400" />
          </h3>
          <p className="text-gray-300">CPU: 45% | Memory: 68%</p>
        </div>
        <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
          <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
            <AlertTriangle className="mr-2 text-yellow-400" size={20} /> Live Alerts
          </h3>
          {alerts.map(alert => (
            <div key={alert.id} onClick={() => setSelectedAlert(alert)} className="p-3 bg-gray-700 rounded-lg cursor-pointer">
              <h4 className="text-white text-sm">{alert.title}</h4>
              <p className="text-xs text-gray-400">{alert.source} • {alert.location}</p>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
          <BarChart3 className="mr-2 text-blue-400" size={20} /> Threat Activity Timeline
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={threatData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="time" stroke="#9CA3AF" />
              <YAxis stroke="#9CA3AF" />
              <Tooltip contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #374151' }} />
              <Area type="monotone" dataKey="threats" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.3} />
              <Area type="monotone" dataKey="blocked" stroke="#10B981" fill="#10B981" fillOpacity={0.3} />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
      <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
        <h3 className="text-xl font-semibold text-white mb-4 flex items-center">
          <Users className="mr-2 text-purple-400" size={20} /> Agent Status
        </h3>
        {agentStatus.map(agent => (
          <div key={agent.name} className="flex justify-between p-3 bg-gray-700 rounded-lg">
            <div className="text-white">{agent.name}</div>
            <div className="text-gray-400 text-sm">{agent.lastScan}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
