import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from datetime import datetime, timedelta
import json
import os

# Import custom modules
from agents.vulneye import VulnEyeAgent
from agents.threat_sentinel import ThreatSentinelAgent
from agents.malware_mind import MalwareMindAgent
from agents.patch_master import PatchMasterAgent
from agents.threat_fusion import ThreatFusionBrain
from agents.blue_team_copilot import BlueTeamCopilot
from agents.red_team_simulator import RedTeamSimulator
from engines.risk_scoring import RiskScoringEngine
from engines.memory_module import MemoryModule
from engines.vector_memory import VectorMemoryModule
from utils.visualizations import create_threat_timeline, create_risk_heatmap, create_attack_graph
from utils.export_utils import export_to_json, export_to_csv, export_to_markdown, get_export_filename

# Page configuration
st.set_page_config(
    page_title="SentinelNexus - AI Security Platform",
    page_icon="🛡️",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Initialize session state
if 'use_vector_db' not in st.session_state:
    st.session_state.use_vector_db = True
if 'memory_module' not in st.session_state:
    if st.session_state.use_vector_db:
        try:
            st.session_state.memory_module = VectorMemoryModule()
        except Exception as e:
            st.warning(f"Vector database initialization failed, falling back to JSON storage: {str(e)}")
            st.session_state.use_vector_db = False
            st.session_state.memory_module = MemoryModule()
    else:
        st.session_state.memory_module = MemoryModule()
if 'vulneye' not in st.session_state:
    st.session_state.vulneye = VulnEyeAgent(st.session_state.memory_module)
if 'threat_sentinel' not in st.session_state:
    st.session_state.threat_sentinel = ThreatSentinelAgent(st.session_state.memory_module)
if 'malware_mind' not in st.session_state:
    st.session_state.malware_mind = MalwareMindAgent(st.session_state.memory_module)
if 'patch_master' not in st.session_state:
    st.session_state.patch_master = PatchMasterAgent()
if 'threat_fusion' not in st.session_state:
    st.session_state.threat_fusion = ThreatFusionBrain(st.session_state.memory_module)
if 'copilot' not in st.session_state:
    st.session_state.copilot = BlueTeamCopilot(st.session_state.memory_module)
if 'red_team' not in st.session_state:
    st.session_state.red_team = RedTeamSimulator()
if 'risk_engine' not in st.session_state:
    st.session_state.risk_engine = RiskScoringEngine()
if 'scan_running' not in st.session_state:
    st.session_state.scan_running = False

# Custom CSS for SOC theme
st.markdown("""
    <style>
    .metric-card {
        padding: 20px;
        border-radius: 5px;
        border-left: 4px solid;
    }
    .critical { border-color: #FF4B4B; }
    .high { border-color: #FFA500; }
    .medium { border-color: #FFD700; }
    .low { border-color: #90EE90; }
    </style>
""", unsafe_allow_html=True)

# Sidebar
with st.sidebar:
    st.image("https://cdn-icons-png.flaticon.com/512/2913/2913133.png", width=100)
    st.title("🛡️ SentinelNexus")
    st.caption("AI-Powered Autonomous Security Infrastructure")
    
    st.divider()
    
    # Navigation
    page = st.radio(
        "Navigation",
        ["🏠 Dashboard", "🔍 Threat Detection", "🦠 Malware Analysis", 
         "🤖 Blue Team Copilot", "⚡ Remediation", "🎯 Red Team Simulator",
         "📊 Risk Analysis", "🧠 Memory & Learning"]
    )
    
    st.divider()
    
    # System Status
    st.subheader("System Status")
    st.success("✅ All Agents Online")
    st.metric("Active Threats", len(st.session_state.memory_module.get_active_threats()))
    st.metric("Total Incidents", len(st.session_state.memory_module.get_all_incidents()))

# Main content area
if page == "🏠 Dashboard":
    st.title("Security Operations Center Dashboard")
    st.caption("Real-time threat intelligence and system monitoring")
    
    # Top metrics
    col1, col2, col3, col4 = st.columns(4)
    
    active_threats = st.session_state.memory_module.get_active_threats()
    all_incidents = st.session_state.memory_module.get_all_incidents()
    
    with col1:
        st.metric("🚨 Active Threats", len(active_threats), delta=-2 if len(active_threats) < 5 else 3)
    
    with col2:
        critical_count = sum(1 for t in active_threats if t.get('severity') == 'critical')
        st.metric("🔴 Critical Alerts", critical_count, delta=1 if critical_count > 0 else 0)
    
    with col3:
        st.metric("📊 Risk Score", f"{st.session_state.risk_engine.get_overall_risk_score():.1f}/10", delta=-0.5)
    
    with col4:
        st.metric("🛡️ Protected Assets", 47, delta=2)
    
    st.divider()
    
    # Real-time threat feed and visualization
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Threat Timeline")
        timeline_fig = create_threat_timeline(all_incidents)
        st.plotly_chart(timeline_fig, use_container_width=True)
    
    with col2:
        st.subheader("Active Threats")
        if active_threats:
            for threat in active_threats[:5]:
                severity = threat.get('severity', 'medium')
                st.markdown(f"""
                <div class="metric-card {severity}">
                    <strong>{threat.get('type', 'Unknown')}</strong><br>
                    <small>{threat.get('description', 'No description')}</small><br>
                    <small>Detected: {threat.get('timestamp', 'Unknown')}</small>
                </div>
                """, unsafe_allow_html=True)
                st.markdown("<br>", unsafe_allow_html=True)
        else:
            st.info("No active threats detected")
    
    st.divider()
    
    # Risk heatmap
    st.subheader("Asset Risk Heatmap")
    heatmap_fig = create_risk_heatmap(st.session_state.risk_engine)
    st.plotly_chart(heatmap_fig, use_container_width=True)

elif page == "🔍 Threat Detection":
    st.title("Threat Detection & Vulnerability Analysis")
    
    tab1, tab2, tab3 = st.tabs(["🔎 VulnEye Scanner", "🛡️ ThreatSentinel", "🧩 Threat Correlation"])
    
    with tab1:
        st.subheader("VulnEye - Vulnerability Scanner")
        st.caption("Real-time CVE detection and prioritization")
        
        col1, col2 = st.columns([3, 1])
        with col1:
            target = st.text_input("Target System/IP", placeholder="e.g., 192.168.1.100 or web-server-01")
        with col2:
            if st.button("🔍 Start Scan", type="primary", disabled=st.session_state.scan_running):
                st.session_state.scan_running = True
                st.rerun()
        
        if st.session_state.scan_running:
            with st.spinner("Scanning for vulnerabilities..."):
                vulnerabilities = st.session_state.vulneye.scan_target(target if target else "demo-system")
                st.session_state.scan_running = False
            
            st.success(f"Scan complete! Found {len(vulnerabilities)} vulnerabilities")
            
            if vulnerabilities:
                # Display vulnerabilities
                for vuln in vulnerabilities:
                    severity = vuln['severity'].lower()
                    with st.expander(f"{vuln['cve_id']} - {vuln['severity']} ({vuln['cvss_score']}/10)"):
                        st.markdown(f"**Description:** {vuln['description']}")
                        st.markdown(f"**Asset:** {vuln['asset']}")
                        st.markdown(f"**Priority Score:** {vuln['priority_score']:.2f}")
                        st.markdown(f"**Exploitability:** {vuln['exploitability']}")
                        
                        if vuln.get('patch_available'):
                            st.success("✅ Patch available")
                        else:
                            st.warning("⚠️ No patch available - consider mitigation")
    
    with tab2:
        st.subheader("ThreatSentinel - Real-time Threat Detection")
        st.caption("Log analysis and anomaly detection using MITRE ATT&CK")
        
        analysis_mode = st.radio("Analysis Mode", ["Simulated Logs", "Upload Log File"])
        
        if analysis_mode == "Simulated Logs":
            if st.button("🔄 Analyze Recent Logs"):
                with st.spinner("Analyzing logs for threats..."):
                    detections = st.session_state.threat_sentinel.analyze_logs()
                
                st.success(f"Analysis complete! {len(detections)} threats detected")
                
                if detections:
                    for detection in detections:
                        with st.expander(f"{detection['attack_type']} - {detection['severity'].upper()}"):
                            st.markdown(f"**MITRE Technique:** {detection['mitre_technique']}")
                            st.markdown(f"**Description:** {detection['description']}")
                            st.markdown(f"**Confidence:** {detection['confidence']:.0%}")
                            st.markdown(f"**Affected Host:** {detection['host']}")
                            st.markdown(f"**Timestamp:** {detection['timestamp']}")
                            
                            st.json(detection['indicators'])
        else:
            st.markdown("Upload security log files for analysis")
            
            log_format = st.selectbox(
                "Log Format",
                ["generic", "zeek", "suricata", "sysmon"],
                help="Select the format of your log file"
            )
            
            uploaded_file = st.file_uploader("Choose a log file", type=["log", "txt", "json"])
            
            if uploaded_file is not None:
                if st.button("🔍 Analyze Log File"):
                    with st.spinner("Parsing and analyzing log file..."):
                        log_content = uploaded_file.read().decode('utf-8')
                        detections = st.session_state.threat_sentinel.analyze_log_file(log_content, log_format)
                    
                    if detections:
                        st.success(f"Analysis complete! {len(detections)} threats detected in log file")
                        
                        for detection in detections:
                            with st.expander(f"{detection['attack_type']} - {detection['severity'].upper()}"):
                                st.markdown(f"**MITRE Technique:** {detection['mitre_technique']}")
                                st.markdown(f"**Description:** {detection['description']}")
                                st.markdown(f"**Confidence:** {detection['confidence']:.0%}")
                                st.markdown(f"**Affected Host:** {detection['host']}")
                                st.markdown(f"**Timestamp:** {detection['timestamp']}")
                                
                                st.json(detection['indicators'])
                    else:
                        st.info("No threats detected in the log file")
    
    with tab3:
        st.subheader("Threat Correlation & Intelligence")
        st.caption("Graph-based threat analysis powered by ThreatFusion Brain")
        
        if st.button("🧠 Generate Threat Correlation Graph"):
            with st.spinner("Correlating threat intelligence..."):
                graph_data = st.session_state.threat_fusion.generate_correlation_graph()
            
            st.success("Correlation analysis complete")
            
            analytics = graph_data.get('analytics', {})
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric("Total Nodes", analytics.get('total_nodes', 0))
            with col2:
                st.metric("Total Connections", analytics.get('total_edges', 0))
            with col3:
                most_connected = analytics.get('most_connected', 'N/A')
                st.metric("Most Connected", most_connected if most_connected else 'N/A')
            
            st.divider()
            
            attack_graph = create_attack_graph(graph_data)
            st.plotly_chart(attack_graph, use_container_width=True)
            
            if analytics.get('most_central'):
                st.info(f"**Key Insight:** {analytics['most_central']} is the most central node in the threat network, indicating it's a critical pivot point for correlating threats.")
            
            st.subheader("Attack Chain Prediction")
            predictions = st.session_state.threat_fusion.predict_attack_chain()
            
            for i, step in enumerate(predictions, 1):
                st.markdown(f"**Step {i}:** {step['technique']} - {step['description']}")
                st.progress(step['probability'])

elif page == "🦠 Malware Analysis":
    st.title("MalwareMind - Intelligent Malware Analysis")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Upload Sample or Analyze Detected Malware")
        
        analysis_type = st.radio("Analysis Type", ["Recent Detections", "Simulate Sample Analysis"])
        
        if analysis_type == "Recent Detections":
            if st.button("🔍 Analyze Recent Malware Detections"):
                with st.spinner("Analyzing malware samples..."):
                    results = st.session_state.malware_mind.analyze_recent_detections()
                
                st.success(f"Analysis complete! {len(results)} samples analyzed")
                
                for result in results:
                    with st.expander(f"Sample: {result['hash']} - {result['classification']}"):
                        st.markdown(f"**Malware Family:** {result['family']}")
                        st.markdown(f"**Threat Level:** {result['threat_level']}")
                        st.markdown(f"**Confidence:** {result['confidence']:.0%}")
                        
                        st.markdown("**MITRE ATT&CK Techniques:**")
                        for technique in result['mitre_techniques']:
                            st.code(technique)
                        
                        st.markdown("**Behavioral Indicators:**")
                        for behavior in result['behaviors']:
                            st.markdown(f"- {behavior}")
                        
                        st.markdown("**Network IOCs:**")
                        st.json(result['network_iocs'])
        
        else:
            file_hash = st.text_input("File Hash (SHA256)", placeholder="Enter hash to simulate analysis")
            if st.button("Analyze Sample") and file_hash:
                with st.spinner("Deep analysis in progress..."):
                    result = st.session_state.malware_mind.deep_analysis(file_hash)
                
                st.success("Analysis complete!")
                st.json(result)
    
    with col2:
        st.subheader("Malware Statistics")
        
        stats = st.session_state.malware_mind.get_statistics()
        
        st.metric("Total Samples Analyzed", stats['total_samples'])
        st.metric("Unique Families", stats['unique_families'])
        st.metric("High Severity", stats['high_severity'])
        
        st.divider()
        
        st.subheader("Top Malware Families")
        family_data = pd.DataFrame(stats['top_families'])
        if not family_data.empty:
            fig = px.pie(family_data, names='family', values='count', 
                        title="Distribution by Family")
            st.plotly_chart(fig, use_container_width=True)

elif page == "🤖 Blue Team Copilot":
    st.title("Blue Team Copilot - AI Security Analyst")
    st.caption("Natural language security queries powered by GPT-5")
    
    # Check for OpenAI API key
    if not os.getenv("OPENAI_API_KEY"):
        st.error("⚠️ OpenAI API key not configured. Please set OPENAI_API_KEY environment variable.")
        st.stop()
    
    # Display conversation history
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    
    # Chat interface
    st.subheader("Ask the Copilot")
    
    # Example queries
    st.caption("Example queries:")
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("💡 What are the top threats?"):
            st.session_state.pending_query = "What are the top active threats in the system right now?"
    with col2:
        if st.button("💡 Explain latest incident"):
            st.session_state.pending_query = "Explain the most recent security incident and why it was flagged"
    with col3:
        if st.button("💡 Recommend actions"):
            st.session_state.pending_query = "What security actions should I prioritize right now?"
    
    # Display chat history
    for msg in st.session_state.chat_history:
        with st.chat_message(msg['role']):
            st.markdown(msg['content'])
    
    # Chat input
    if 'pending_query' in st.session_state:
        user_query = st.session_state.pending_query
        del st.session_state.pending_query
    else:
        user_query = st.chat_input("Ask about threats, incidents, or security recommendations...")
    
    if user_query:
        # Add user message
        st.session_state.chat_history.append({"role": "user", "content": user_query})
        with st.chat_message("user"):
            st.markdown(user_query)
        
        # Get copilot response
        with st.chat_message("assistant"):
            with st.spinner("Analyzing..."):
                response = st.session_state.copilot.query(user_query)
            st.markdown(response)
        
        st.session_state.chat_history.append({"role": "assistant", "content": response})
        st.rerun()

elif page == "⚡ Remediation":
    st.title("PatchMaster AI - Intelligent Remediation")
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        st.subheader("Priority Remediation Queue")
        
        # Get remediation suggestions
        suggestions = st.session_state.patch_master.generate_suggestions(
            st.session_state.memory_module.get_active_threats()
        )
        
        if suggestions:
            for i, suggestion in enumerate(suggestions, 1):
                priority_color = {
                    'critical': '🔴',
                    'high': '🟠',
                    'medium': '🟡',
                    'low': '🟢'
                }
                
                with st.expander(f"{priority_color.get(suggestion['priority'], '⚪')} [{suggestion['priority'].upper()}] {suggestion['title']}"):
                    st.markdown(f"**Target:** {suggestion['target']}")
                    st.markdown(f"**Issue:** {suggestion['issue']}")
                    st.markdown(f"**Impact:** {suggestion['impact']}")
                    
                    st.markdown("**Recommended Actions:**")
                    for action in suggestion['actions']:
                        st.markdown(f"- {action}")
                    
                    st.markdown(f"**Estimated Time:** {suggestion['estimated_time']}")
                    st.markdown(f"**Dependencies:** {', '.join(suggestion['dependencies']) if suggestion['dependencies'] else 'None'}")
                    
                    col_a, col_b, col_c = st.columns(3)
                    with col_a:
                        if st.button(f"✅ Execute", key=f"exec_{i}"):
                            st.success(f"Executing remediation plan: {suggestion['title']}")
                    with col_b:
                        if st.button(f"📋 Generate Script", key=f"script_{i}"):
                            script = st.session_state.patch_master.generate_script(suggestion)
                            st.code(script, language='bash')
                    with col_c:
                        if st.button(f"🔍 Simulate", key=f"sim_{i}"):
                            st.info("Simulation mode: Actions will be logged but not executed")
        else:
            st.success("✅ No pending remediations - system is secure!")
    
    with col2:
        st.subheader("Remediation Stats")
        stats = st.session_state.patch_master.get_statistics()
        
        st.metric("Total Remediations", stats['total_suggested'])
        st.metric("Auto-Executed", stats['auto_executed'])
        st.metric("Success Rate", f"{stats['success_rate']:.1%}")
        
        st.divider()
        
        st.subheader("Recent Activity")
        for activity in stats['recent_activities'][:5]:
            st.markdown(f"**{activity['timestamp']}**")
            st.caption(activity['description'])

elif page == "🎯 Red Team Simulator":
    st.title("Red Team Simulator - Attack Scenario Testing")
    
    st.caption("Simulate real-world attacks to test detection and response capabilities")
    
    st.subheader("Available Attack Scenarios")
    
    scenarios = st.session_state.red_team.get_scenarios()
    
    col1, col2 = st.columns([2, 1])
    
    with col1:
        selected_scenario = st.selectbox(
            "Select Attack Scenario",
            options=[s['name'] for s in scenarios],
            format_func=lambda x: f"{'🔴' if next(s for s in scenarios if s['name']==x)['severity']=='critical' else '🟡'} {x}"
        )
        
        scenario = next(s for s in scenarios if s['name'] == selected_scenario)
        
        st.markdown(f"**Description:** {scenario['description']}")
        st.markdown(f"**MITRE Techniques:** {', '.join(scenario['mitre_techniques'])}")
        st.markdown(f"**Severity:** {scenario['severity'].upper()}")
        
        st.divider()
        
        if st.button("🚀 Launch Simulation", type="primary"):
            st.warning("⚠️ Simulation starting - all activities will be logged")
            
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Simulate attack
            results = st.session_state.red_team.simulate_attack(scenario['name'])
            
            for i, step in enumerate(results['steps']):
                progress_bar.progress((i + 1) / len(results['steps']))
                status_text.text(f"Executing: {step['action']}")
                
            st.success("✅ Simulation Complete!")
            
            st.subheader("Simulation Results")
            
            col_a, col_b, col_c = st.columns(3)
            with col_a:
                st.metric("Total Steps", results['total_steps'])
            with col_b:
                st.metric("Detected", results['detected_steps'])
            with col_c:
                detection_rate = (results['detected_steps'] / results['total_steps']) * 100
                st.metric("Detection Rate", f"{detection_rate:.1f}%")
            
            st.subheader("Step-by-Step Analysis")
            for step in results['steps']:
                detected = "✅ Detected" if step['detected'] else "❌ Missed"
                with st.expander(f"{step['action']} - {detected}"):
                    st.markdown(f"**Technique:** {step['technique']}")
                    st.markdown(f"**Description:** {step['description']}")
                    if step['detected']:
                        st.markdown(f"**Detection Method:** {step['detection_method']}")
                    else:
                        st.warning("This step was not detected - consider improving detection rules")
    
    with col2:
        st.subheader("Historical Simulations")
        history = st.session_state.red_team.get_simulation_history()
        
        st.metric("Total Simulations", len(history))
        avg_detection = sum(h['detection_rate'] for h in history) / len(history) if history else 0
        st.metric("Avg Detection Rate", f"{avg_detection:.1f}%")
        
        st.divider()
        
        st.subheader("Recent Tests")
        for sim in history[:5]:
            st.markdown(f"**{sim['scenario']}**")
            st.caption(f"{sim['timestamp']} - {sim['detection_rate']:.1f}% detected")

elif page == "📊 Risk Analysis":
    st.title("Risk Scoring & Analysis Engine")
    
    st.subheader("Overall Risk Assessment")
    
    col1, col2, col3, col4 = st.columns(4)
    
    overall_risk = st.session_state.risk_engine.get_overall_risk_score()
    
    with col1:
        st.metric("Overall Risk Score", f"{overall_risk:.1f}/10")
    with col2:
        threat_score = st.session_state.risk_engine.calculate_threat_score()
        st.metric("Threat Score", f"{threat_score:.1f}/10")
    with col3:
        asset_score = st.session_state.risk_engine.calculate_asset_score()
        st.metric("Asset Exposure", f"{asset_score:.1f}/10")
    with col4:
        historical_score = st.session_state.risk_engine.calculate_historical_score()
        st.metric("Historical Risk", f"{historical_score:.1f}/10")
    
    st.divider()
    
    # Risk factors breakdown
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Risk Factor Breakdown")
        factors = st.session_state.risk_engine.get_risk_factors()
        
        factor_df = pd.DataFrame(factors)
        fig = px.bar(factor_df, x='score', y='factor', orientation='h',
                    title="Risk Contribution by Factor",
                    color='score', color_continuous_scale='Reds')
        st.plotly_chart(fig, use_container_width=True)
    
    with col2:
        st.subheader("Risk Trend Analysis")
        trend_data = st.session_state.risk_engine.get_risk_trend()
        
        trend_df = pd.DataFrame(trend_data)
        fig = px.line(trend_df, x='date', y='score', 
                     title="Risk Score Over Time",
                     markers=True)
        st.plotly_chart(fig, use_container_width=True)
    
    st.divider()
    
    # Asset-specific risk
    st.subheader("Asset Risk Matrix")
    
    asset_risks = st.session_state.risk_engine.get_asset_risks()
    
    for asset in asset_risks:
        risk_level = asset['risk_level']
        color_map = {
            'critical': '#FF4B4B',
            'high': '#FFA500',
            'medium': '#FFD700',
            'low': '#90EE90'
        }
        
        st.markdown(f"""
        <div class="metric-card {risk_level}" style="border-color: {color_map.get(risk_level, '#ccc')}">
            <strong>{asset['name']}</strong> - {asset['type']}<br>
            <small>Risk Score: {asset['risk_score']:.1f}/10 | Criticality: {asset['criticality']}</small><br>
            <small>Threats: {asset['active_threats']} | Vulnerabilities: {asset['vulnerabilities']}</small>
        </div>
        """, unsafe_allow_html=True)
        st.markdown("<br>", unsafe_allow_html=True)

elif page == "🧠 Memory & Learning":
    st.title("Memory Module - Adaptive Learning System")
    
    if st.session_state.use_vector_db:
        st.caption("Historical incident tracking with AI-powered semantic search using ChromaDB")
    else:
        st.caption("Historical incident tracking and AI-powered pattern recognition")
    
    tab1, tab2, tab3, tab4 = st.tabs(["📚 Incident History", "🔍 Semantic Search", "🔄 Learning Patterns", "📈 Analytics"])
    
    with tab1:
        st.subheader("Historical Incidents")
        
        incidents = st.session_state.memory_module.get_all_incidents()
        
        if incidents:
            # Filters
            col1, col2, col3 = st.columns(3)
            with col1:
                severity_filter = st.multiselect("Severity", ['critical', 'high', 'medium', 'low'], default=['critical', 'high'])
            with col2:
                type_filter = st.multiselect("Type", list(set(i['type'] for i in incidents)))
            with col3:
                date_range = st.date_input("Date Range", value=[datetime.now() - timedelta(days=30), datetime.now()])
            
            # Filter incidents
            filtered_incidents = [
                i for i in incidents 
                if i.get('severity') in severity_filter
                and (not type_filter or i.get('type') in type_filter)
            ]
            
            st.metric("Total Incidents", len(filtered_incidents))
            
            for incident in filtered_incidents[:20]:
                with st.expander(f"{incident['timestamp']} - {incident['type']} [{incident['severity']}]"):
                    st.markdown(f"**Description:** {incident['description']}")
                    st.markdown(f"**Status:** {incident.get('status', 'Resolved')}")
                    st.markdown(f"**Response Time:** {incident.get('response_time', 'N/A')}")
                    
                    if incident.get('remediation'):
                        st.markdown(f"**Remediation:** {incident['remediation']}")
                    
                    if incident.get('lessons_learned'):
                        st.info(f"💡 Lesson Learned: {incident['lessons_learned']}")
        else:
            st.info("No incidents in memory yet")
    
    with tab2:
        st.subheader("Semantic Search & IOC Lookup")
        
        if st.session_state.use_vector_db:
            st.markdown("Search historical incidents using natural language or find related IOCs")
            
            search_type = st.radio("Search Type", ["Incident Search", "IOC Lookup"])
            
            if search_type == "Incident Search":
                search_query = st.text_input(
                    "Search Query",
                    placeholder="e.g., credential dumping attacks, lateral movement to database servers"
                )
                
                if st.button("🔍 Search") and search_query:
                    with st.spinner("Searching incident database..."):
                        results = st.session_state.memory_module.search_similar_incidents(search_query, limit=10)
                    
                    if results:
                        st.success(f"Found {len(results)} relevant incidents")
                        
                        for result in results:
                            similarity_score = result.get('similarity_score', 0.0)
                            score_color = "🟢" if similarity_score > 0.7 else "🟡" if similarity_score > 0.4 else "🔴"
                            
                            with st.expander(f"{score_color} {result['type']} - {result['severity']} (Relevance: {similarity_score:.2%})"):
                                st.markdown(f"**Timestamp:** {result['timestamp']}")
                                st.markdown(f"**Description:** {result.get('description', 'No description')}")
                                st.markdown(f"**Similarity Score:** {similarity_score:.2%}")
                    else:
                        st.info("No similar incidents found")
            
            else:
                ioc_value = st.text_input(
                    "IOC Value",
                    placeholder="e.g., 192.168.1.100, malicious.com, file hash"
                )
                
                ioc_type = st.selectbox(
                    "IOC Type (Optional)",
                    ["All Types", "ip_address", "domain", "file_hash"]
                )
                
                if st.button("🔍 Search IOCs") and ioc_value:
                    with st.spinner("Searching IOC database..."):
                        ioc_type_filter = None if ioc_type == "All Types" else ioc_type
                        results = st.session_state.memory_module.search_iocs(ioc_value, ioc_type_filter)
                    
                    if results:
                        st.success(f"Found {len(results)} related IOCs")
                        
                        for ioc in results:
                            with st.expander(f"IOC: {ioc['value']} ({ioc['type']}) - Relevance: {ioc.get('relevance', 0):.2%}"):
                                st.markdown(f"**Type:** {ioc['type']}")
                                st.markdown(f"**Context:** {ioc['context']}")
                                st.markdown(f"**First Seen:** {ioc['timestamp']}")
                                st.markdown(f"**Associated Incident:** {ioc['incident_id']}")
                                st.markdown(f"**Relevance:** {ioc.get('relevance', 0):.2%}")
                    else:
                        st.info("No matching IOCs found")
        else:
            st.info("Vector database not enabled. Switch to VectorMemoryModule to use semantic search features.")
    
    with tab3:
        st.subheader("Learning Patterns & Insights")
        
        patterns = st.session_state.memory_module.get_learned_patterns()
        
        st.markdown("### Attack Pattern Recognition")
        for pattern in patterns.get('attack_patterns', []):
            st.markdown(f"""
            **Pattern:** {pattern['name']}  
            **Occurrences:** {pattern['frequency']}  
            **Last Seen:** {pattern['last_seen']}  
            **Recommendation:** {pattern['recommendation']}
            """)
            st.divider()
        
        st.markdown("### False Positive Reduction")
        st.markdown(f"**False Positives Learned:** {patterns.get('false_positives_count', 0)}")
        st.markdown(f"**Accuracy Improvement:** +{patterns.get('accuracy_improvement', 0):.1f}%")
    
    with tab4:
        st.subheader("Memory Analytics & Export")
        
        analytics = st.session_state.memory_module.get_analytics()
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Events Stored", analytics['total_events'])
        with col2:
            st.metric("Unique Threat Types", analytics['unique_threats'])
        with col3:
            st.metric("Learning Rate", f"{analytics['learning_rate']:.2f}")
        
        st.divider()
        
        # Incident type distribution
        st.subheader("Incident Distribution")
        incident_dist = pd.DataFrame(analytics['incident_distribution'])
        if not incident_dist.empty:
            fig = px.pie(incident_dist, names='type', values='count',
                        title="Incidents by Type")
            st.plotly_chart(fig, use_container_width=True)
        
        # Time-based analysis
        st.subheader("Incident Frequency Over Time")
        time_data = pd.DataFrame(analytics['time_series'])
        if not time_data.empty:
            fig = px.line(time_data, x='date', y='count',
                         title="Daily Incident Count",
                         markers=True)
            st.plotly_chart(fig, use_container_width=True)
        
        st.divider()
        
        # Export functionality
        st.subheader("📤 Export Incident Reports")
        st.caption("Export security incidents for compliance, analysis, and reporting")
        
        export_col1, export_col2 = st.columns([2, 1])
        
        with export_col1:
            incidents_to_export = st.session_state.memory_module.get_all_incidents()
            
            st.markdown(f"**{len(incidents_to_export)}** incidents available for export")
            
            export_filters = st.checkbox("Apply severity filter to export", value=False)
            
            if export_filters:
                export_severity = st.multiselect(
                    "Select Severities",
                    ['critical', 'high', 'medium', 'low'],
                    default=['critical', 'high']
                )
                incidents_to_export = [
                    i for i in incidents_to_export 
                    if i.get('severity') in export_severity
                ]
                st.info(f"Filtered to {len(incidents_to_export)} incidents")
        
        with export_col2:
            export_format = st.selectbox(
                "Export Format",
                ["JSON", "CSV", "Markdown"],
                help="Choose the format for your export"
            )
        
        if st.button("📥 Generate Export", type="primary"):
            if not incidents_to_export:
                st.warning("No incidents to export")
            else:
                with st.spinner(f"Generating {export_format} export..."):
                    if export_format == "JSON":
                        export_data = export_to_json(incidents_to_export)
                        filename = get_export_filename("json")
                        mime_type = "application/json"
                    elif export_format == "CSV":
                        export_data = export_to_csv(incidents_to_export)
                        filename = get_export_filename("csv")
                        mime_type = "text/csv"
                    else:
                        export_data = export_to_markdown(incidents_to_export)
                        filename = get_export_filename("md")
                        mime_type = "text/markdown"
                
                st.success(f"Export generated successfully: {len(incidents_to_export)} incidents")
                
                st.download_button(
                    label=f"⬇️ Download {export_format} Report",
                    data=export_data,
                    file_name=filename,
                    mime=mime_type
                )

# Footer
st.divider()
st.caption("SentinelNexus v1.0 | AI-Powered Autonomous Security Infrastructure")
st.caption("Powered by: VulnEye • ThreatSentinel • MalwareMind • PatchMaster • ThreatFusion • Blue Team Copilot")
