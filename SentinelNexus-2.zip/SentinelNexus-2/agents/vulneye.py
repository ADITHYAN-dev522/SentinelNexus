"""
VulnEye Agent - Vulnerability Detection & Patch Prioritization
Uses CVE APIs to detect system vulnerabilities and prioritize patches
"""

import random
from datetime import datetime
from utils.cve_api import CVEApi

class VulnEyeAgent:
    def __init__(self, memory_module):
        self.memory = memory_module
        self.cve_api = CVEApi()
        
    def scan_target(self, target):
        """Scan target system for vulnerabilities"""
        
        # Get recent CVEs from API
        recent_cves = self.cve_api.get_recent_cves(limit=10)
        
        vulnerabilities = []
        
        for cve_data in recent_cves:
            # Calculate priority score based on multiple factors
            priority_score = self._calculate_priority(cve_data)
            
            vuln = {
                'cve_id': cve_data['id'],
                'description': cve_data['description'],
                'cvss_score': cve_data['cvss_score'],
                'severity': cve_data['severity'],
                'asset': target,
                'priority_score': priority_score,
                'exploitability': cve_data.get('exploitability', 'Unknown'),
                'patch_available': cve_data.get('patch_available', False),
                'timestamp': datetime.now().isoformat(),
                'status': 'open'
            }
            
            vulnerabilities.append(vuln)
            
            # Store in memory
            self.memory.add_incident({
                'type': 'vulnerability',
                'severity': cve_data['severity'],
                'description': f"Detected {cve_data['id']} on {target}",
                'timestamp': datetime.now().isoformat(),
                'details': vuln
            })
        
        # Sort by priority score
        vulnerabilities.sort(key=lambda x: x['priority_score'], reverse=True)
        
        return vulnerabilities
    
    def _calculate_priority(self, cve_data):
        """
        Calculate vulnerability priority score based on:
        - CVSS score
        - Exploitability
        - Asset criticality
        - Historical breach data
        """
        base_score = cve_data['cvss_score']
        
        # Exploitability multiplier
        exploit_multiplier = {
            'High': 1.5,
            'Functional': 1.3,
            'POC': 1.1,
            'Unknown': 1.0
        }.get(cve_data.get('exploitability', 'Unknown'), 1.0)
        
        # Patch availability penalty
        patch_penalty = 0.8 if cve_data.get('patch_available') else 1.0
        
        # Calculate final priority (0-10 scale)
        priority = (base_score * exploit_multiplier * patch_penalty)
        
        return min(10.0, priority)
    
    def get_patch_recommendations(self, cve_id):
        """Get patch recommendations for specific CVE"""
        return self.cve_api.get_patch_info(cve_id)
