import json
import csv
import io
from datetime import datetime
from typing import List, Dict, Any

def export_to_json(incidents: List[Dict[str, Any]]) -> str:
    """Export incidents to JSON format"""
    export_data = {
        'export_date': datetime.now().isoformat(),
        'total_incidents': len(incidents),
        'incidents': incidents
    }
    return json.dumps(export_data, indent=2)

def export_to_csv(incidents: List[Dict[str, Any]]) -> str:
    """Export incidents to CSV format with all fields dynamically included"""
    if not incidents:
        return "No incidents to export"
    
    output = io.StringIO()
    
    fieldnames = set()
    for incident in incidents:
        for key in incident.keys():
            if key != 'details':
                fieldnames.add(key)
        
        if 'details' in incident and isinstance(incident['details'], dict):
            for detail_key in incident['details'].keys():
                fieldnames.add(f"details_{detail_key}")
    
    fieldnames = sorted(list(fieldnames))
    
    writer = csv.DictWriter(output, fieldnames=fieldnames, extrasaction='ignore')
    writer.writeheader()
    
    for incident in incidents:
        row = {}
        
        for key, value in incident.items():
            if key == 'details' and isinstance(value, dict):
                for detail_key, detail_value in value.items():
                    if isinstance(detail_value, (dict, list)):
                        row[f'details_{detail_key}'] = json.dumps(detail_value)
                    else:
                        row[f'details_{detail_key}'] = str(detail_value) if detail_value is not None else ''
            elif isinstance(value, (dict, list)):
                row[key] = json.dumps(value)
            else:
                row[key] = str(value) if value is not None else ''
        
        writer.writerow(row)
    
    return output.getvalue()

def export_to_markdown(incidents: List[Dict[str, Any]]) -> str:
    """Export incidents to Markdown format for reporting with all fields"""
    if not incidents:
        return "# Security Incident Report\n\nNo incidents to report."
    
    md_lines = [
        "# Security Incident Report",
        f"\n**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        f"\n**Total Incidents:** {len(incidents)}",
        "\n---\n"
    ]
    
    severity_counts = {}
    for incident in incidents:
        severity = incident.get('severity', 'unknown')
        severity_counts[severity] = severity_counts.get(severity, 0) + 1
    
    md_lines.append("## Summary by Severity\n")
    for severity, count in sorted(severity_counts.items()):
        md_lines.append(f"- **{severity.upper()}**: {count}")
    
    md_lines.append("\n---\n## Detailed Incidents\n")
    
    for i, incident in enumerate(incidents, 1):
        md_lines.append(f"### {i}. {incident.get('type', 'Unknown')} - {incident.get('severity', 'unknown').upper()}")
        md_lines.append(f"\n**ID:** `{incident.get('id', 'N/A')}`")
        
        core_fields = {'id', 'type', 'severity', 'details'}
        
        for key, value in incident.items():
            if key in core_fields:
                continue
            
            formatted_key = key.replace('_', ' ').title()
            
            if isinstance(value, (dict, list)):
                md_lines.append(f"\n**{formatted_key}:**")
                md_lines.append(f"```json\n{json.dumps(value, indent=2)}\n```")
            else:
                md_lines.append(f"\n**{formatted_key}:** {value}")
        
        if 'details' in incident and isinstance(incident['details'], dict):
            md_lines.append("\n**Details:**")
            for key, value in incident['details'].items():
                formatted_key = key.replace('_', ' ').title()
                if isinstance(value, (dict, list)):
                    md_lines.append(f"\n*{formatted_key}:*")
                    md_lines.append(f"```json\n{json.dumps(value, indent=2)}\n```")
                else:
                    md_lines.append(f"- {formatted_key}: {value}")
        
        md_lines.append("\n---\n")
    
    return "\n".join(md_lines)

def get_export_filename(format_type: str) -> str:
    """Generate filename for export"""
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    return f"sentinelnexus_incidents_{timestamp}.{format_type}"
