import React from 'react';
import { Database, Search } from 'lucide-react';

const KnowledgeBase = () => (
  <div className="space-y-6">
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      <div className="bg-gray-800 p-6 rounded-2xl border border-gray-700 shadow-lg">
        <Database className="text-blue-400" />
        <h3 className="text-white">Vulnerability DB</h3>
        <p className="text-gray-400 text-sm">2,341 entries</p>
      </div>
    </div>

    <div className="bg-gray-800 p-6 rounded-2xl border border-gray-700 shadow-lg">
      <h3 className="text-xl text-white mb-4 flex items-center"><Search className="mr-2 text-green-400" /> Search KB</h3>
      <input type="text" placeholder="Search CVEs or IOCs..." className="w-full px-4 py-2 bg-gray-700 rounded-lg text-white" />
    </div>
  </div>
);

export default KnowledgeBase;
