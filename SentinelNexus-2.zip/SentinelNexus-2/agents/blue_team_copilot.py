"""
Blue Team Copilot - LLM-powered Security Analyst
Uses GPT-5 for natural language security queries and explanations
"""

import os
import json
from openai import OpenAI

class BlueTeamCopilot:
    def __init__(self, memory_module):
        self.memory = memory_module
        
        # Initialize OpenAI client
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY environment variable not set")
        
        self.client = OpenAI(api_key=api_key)
        
    def query(self, user_question):
        """
        Process natural language security query using GPT-5
        
        Note: the newest OpenAI model is "gpt-5" which was released August 7, 2025.
        Do not change this unless explicitly requested by the user
        """
        
        # Get context from memory
        context = self._build_context()
        
        # Create system prompt
        system_prompt = f"""You are a Blue Team Security Analyst AI assistant with expertise in:
- Threat detection and analysis
- Vulnerability assessment
- Incident response
- MITRE ATT&CK framework
- Security operations

You have access to the following current security context:

{context}

Provide clear, actionable security analysis and recommendations. Be specific and reference actual data from the context when available."""

        try:
            # Call GPT-5 for analysis
            response = self.client.chat.completions.create(
                model="gpt-5",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_question}
                ]
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"Error communicating with AI assistant: {str(e)}"
    
    def explain_incident(self, incident):
        """Get detailed explanation of a specific incident"""
        
        system_prompt = """You are a security expert explaining incidents to analysts.
Provide clear, educational explanations covering:
1. What happened
2. Why it's significant
3. Potential impact
4. Recommended response
5. How to prevent similar incidents"""

        incident_summary = json.dumps(incident, indent=2)
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-5",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Explain this security incident:\n\n{incident_summary}"}
                ]
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"Error generating explanation: {str(e)}"
    
    def suggest_investigation_steps(self, threat_type):
        """Suggest investigation steps for a specific threat"""
        
        system_prompt = """You are guiding a security analyst through an investigation.
Provide a step-by-step investigation plan with specific commands and tools."""

        try:
            response = self.client.chat.completions.create(
                model="gpt-5",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": f"Provide investigation steps for: {threat_type}"}
                ]
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"Error generating investigation steps: {str(e)}"
    
    def _build_context(self):
        """Build security context from memory"""
        
        active_threats = self.memory.get_active_threats()
        recent_incidents = self.memory.get_all_incidents()[-10:]  # Last 10 incidents
        
        context = f"""
ACTIVE THREATS ({len(active_threats)}):
{json.dumps(active_threats[:5], indent=2)}

RECENT INCIDENTS ({len(recent_incidents)}):
{json.dumps([
    {
        'type': i['type'],
        'severity': i['severity'],
        'description': i['description'],
        'timestamp': i['timestamp']
    }
    for i in recent_incidents
], indent=2)}
"""
        
        return context
