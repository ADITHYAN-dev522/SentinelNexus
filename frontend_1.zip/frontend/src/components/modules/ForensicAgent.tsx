import React from 'react';

const Placeholder = ({ name }) => (
  <div className="flex items-center justify-center h-64 text-gray-400">
    🚧 {name} Module Under Development
  </div>
);

export const ForensicAgent = () => <Placeholder name="Forensic Agent" />;
