import React from 'react';
import { Shield, MessageSquare, Sun, Moon } from 'lucide-react';

const Header = ({ currentTime, isDark, setIsDark, setChatOpen }) => (
  <header className="bg-gray-800 border-b border-gray-700 px-6 py-4">
    <div className="flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <Shield className="text-blue-400" size={32} />
        <div>
          <h1 className="text-2xl font-bold">SentinelNexus</h1>
          <p className="text-gray-400 text-sm">Advanced Cybersecurity Platform</p>
        </div>
      </div>
      <div className="flex items-center space-x-4">
        <div className="text-sm text-gray-300">{currentTime.toLocaleString()}</div>
        <button onClick={() => setIsDark(!isDark)} className="p-2 text-gray-400 hover:text-white">
          {isDark ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        <button onClick={() => setChatOpen(true)} className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
          <MessageSquare size={20} />
        </button>
      </div>
    </div>
  </header>
);

export default Header;