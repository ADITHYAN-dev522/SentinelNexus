"""
Risk Scoring Engine - Calculate risk scores for threats and assets
"""

import random
from datetime import datetime, timedelta

class RiskScoringEngine:
    def __init__(self):
        # Define asset inventory with criticality
        self.assets = [
            {'name': 'Database Server 01', 'type': 'Database', 'criticality': 9.5},
            {'name': 'Web Server 01', 'type': 'Web Server', 'criticality': 8.0},
            {'name': 'Domain Controller', 'type': 'Active Directory', 'criticality': 9.8},
            {'name': 'File Server', 'type': 'File Storage', 'criticality': 7.5},
            {'name': 'Email Server', 'type': 'Email', 'criticality': 8.5},
            {'name': 'Workstation-Finance-01', 'type': 'Workstation', 'criticality': 6.5},
            {'name': 'Workstation-HR-02', 'type': 'Workstation', 'criticality': 7.0},
            {'name': 'VPN Gateway', 'type': 'Network Device', 'criticality': 8.8},
            {'name': 'Backup Server', 'type': 'Backup', 'criticality': 9.0},
            {'name': 'API Gateway', 'type': 'API', 'criticality': 8.2}
        ]
    
    def get_overall_risk_score(self):
        """Calculate overall organizational risk score (0-10)"""
        
        # Factors contributing to risk
        threat_score = self.calculate_threat_score()
        asset_score = self.calculate_asset_score()
        historical_score = self.calculate_historical_score()
        
        # Weighted average
        overall = (threat_score * 0.4) + (asset_score * 0.3) + (historical_score * 0.3)
        
        return round(overall, 1)
    
    def calculate_threat_score(self):
        """Calculate threat severity score"""
        # Simulate based on number and severity of threats
        severity_weights = {'critical': 10, 'high': 7, 'medium': 4, 'low': 2}
        
        # Simulate some active threats
        threats = [
            {'severity': 'critical', 'count': random.randint(0, 2)},
            {'severity': 'high', 'count': random.randint(1, 4)},
            {'severity': 'medium', 'count': random.randint(2, 6)},
            {'severity': 'low', 'count': random.randint(3, 8)}
        ]
        
        total_score = sum(severity_weights[t['severity']] * t['count'] for t in threats)
        max_score = 100  # Normalize to 0-10
        
        return min(10.0, (total_score / max_score) * 10)
    
    def calculate_asset_score(self):
        """Calculate asset exposure score"""
        # Simulate vulnerability exposure
        exposed_assets = random.randint(3, 7)
        total_assets = len(self.assets)
        
        exposure_rate = exposed_assets / total_assets
        
        return round(exposure_rate * 10, 1)
    
    def calculate_historical_score(self):
        """Calculate risk based on historical patterns"""
        # Simulate historical incident frequency
        recent_incidents = random.randint(5, 15)
        incident_severity_avg = random.uniform(4.0, 7.5)
        
        return min(10.0, (recent_incidents / 10) * incident_severity_avg)
    
    def get_risk_factors(self):
        """Get breakdown of risk factors"""
        return [
            {'factor': 'Active Threats', 'score': self.calculate_threat_score()},
            {'factor': 'Asset Exposure', 'score': self.calculate_asset_score()},
            {'factor': 'Historical Risk', 'score': self.calculate_historical_score()},
            {'factor': 'Vulnerability Density', 'score': random.uniform(3.0, 7.0)},
            {'factor': 'Patch Compliance', 'score': random.uniform(2.0, 6.0)}
        ]
    
    def get_risk_trend(self):
        """Get risk score trend over time"""
        trend_data = []
        base_score = 6.5
        
        for i in range(30):
            date = (datetime.now() - timedelta(days=29-i)).strftime('%Y-%m-%d')
            # Simulate fluctuating risk score
            score = base_score + random.uniform(-1.5, 1.5)
            trend_data.append({'date': date, 'score': round(score, 1)})
        
        return trend_data
    
    def get_asset_risks(self):
        """Get risk assessment for each asset"""
        asset_risks = []
        
        for asset in self.assets:
            # Calculate asset-specific risk
            base_risk = asset['criticality']
            
            # Add random factors
            vulnerabilities = random.randint(0, 5)
            active_threats = random.randint(0, 3)
            
            risk_score = base_risk * (1 + (vulnerabilities * 0.1) + (active_threats * 0.15))
            risk_score = min(10.0, risk_score)
            
            # Determine risk level
            if risk_score >= 8.5:
                risk_level = 'critical'
            elif risk_score >= 6.5:
                risk_level = 'high'
            elif risk_score >= 4.0:
                risk_level = 'medium'
            else:
                risk_level = 'low'
            
            asset_risks.append({
                'name': asset['name'],
                'type': asset['type'],
                'criticality': asset['criticality'],
                'risk_score': round(risk_score, 1),
                'risk_level': risk_level,
                'vulnerabilities': vulnerabilities,
                'active_threats': active_threats
            })
        
        return sorted(asset_risks, key=lambda x: x['risk_score'], reverse=True)
