import React, { useState } from 'react';
import { MessageSquare, X } from 'lucide-react';


const HoveringChatBox = ({
isOpen,
onToggle,
messages,
currentMessage,
setCurrentMessage,
onSendMessage
}) => {
if (!isOpen) return null;


return (
<div className="fixed bottom-4 right-4 w-96 bg-gray-800 border border-gray-700 rounded-2xl shadow-lg flex flex-col z-50">
<div className="flex items-center justify-between p-3 border-b border-gray-700">
<h3 className="text-white font-semibold">Sentinel AI Assistant</h3>
<button onClick={onToggle} className="text-gray-400 hover:text-white">
<X size={20} />
</button>
</div>
<div className="flex-1 overflow-y-auto p-4 space-y-3 max-h-64">
{messages.map(msg => (
<div key={msg.id} className={`p-3 rounded-lg ${msg.type === 'user' ? 'bg-blue-600 text-white self-end' : 'bg-gray-700 text-gray-200'}`}>
<p>{msg.message}</p>
<span className="block text-xs text-gray-400 mt-1">{msg.timestamp.toLocaleTimeString()}</span>
</div>
))}
</div>
<div className="p-3 border-t border-gray-700 flex space-x-2">
<input
type="text"
placeholder="Type your message..."
value={currentMessage}
onChange={(e) => setCurrentMessage(e.target.value)}
onKeyDown={(e) => e.key === 'Enter' && onSendMessage()}
className="flex-1 px-3 py-2 bg-gray-700 text-white rounded-lg"
/>
<button onClick={onSendMessage} className="px-3 py-2 bg-blue-600 text-white rounded-lg">
Send
</button>
</div>
</div>
);
};


export default HoveringChatBox;