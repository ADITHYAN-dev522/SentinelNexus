import React, { useState, useEffect } from 'react';
import { Shield, MessageSquare, Sun, Moon } from 'lucide-react';

// Layout Components
import Header from './components/layout/Header';
import Sidebar from './components/layout/Sidebar';
import HoveringChatBox from './components/layout/ChatAssistant';

// Module Components
import Dashboard from './components/modules/Dashboard';
import VulnScanner from './components/modules/VulnScanner';
import MalwareAgent from './components/modules/MalwareAgent';
import ThreatIntel from './components/modules/ThreatIntel';
import Forecasting from './components/modules/Forecasting';
import KnowledgeBase from './components/modules/KnowledgeBase';
import { ResponseAgent, ForensicAgent, Settings } from './components/modules/Placeholders';

// Common Components
import AlertModal from './components/common/AlertModal';

const App = () => {
  const [isDark, setIsDark] = useState(true);
  const [activeModule, setActiveModule] = useState('dashboard');
  const [selectedAlert, setSelectedAlert] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());

  // Chat states
  const [chatMessages, setChatMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [hoveringChatOpen, setHoveringChatOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleChatMessage = () => {
    if (!currentMessage.trim()) return;

    const userMessage = {
      id: Date.now(),
      type: 'user',
      message: currentMessage,
      timestamp: new Date()
    };

    setChatMessages(prev => [...prev, userMessage]);
    setCurrentMessage('');

    setTimeout(() => {
      let aiResponse = '';

      if (currentMessage.toLowerCase().includes('scan') || currentMessage.toLowerCase().includes('vulnerability')) {
        aiResponse = `Based on the latest ${activeModule} scan, I found several vulnerabilities. Would you like me to prioritize them by severity?`;
      } else if (currentMessage.toLowerCase().includes('threat') || currentMessage.toLowerCase().includes('alert')) {
        aiResponse = `I'm monitoring multiple active alerts. The critical APT detection requires immediate attention. Shall I walk you through the incident response procedure?`;
      } else if (currentMessage.toLowerCase().includes('health') || currentMessage.toLowerCase().includes('system')) {
        aiResponse = 'System health is at 98.5%. CPU usage is moderate at 45%, memory at 68%. ForecastingAgent is consuming 82% memory.';
      } else if (currentMessage.toLowerCase().includes('recommendation')) {
        aiResponse = 'I recommend: 1) Patch CVE-2024-8901 immediately (CVSS 9.8), 2) Investigate Lazarus APT indicators, 3) Update malware signatures, 4) Review access logs for unusual login attempts.';
      } else {
        const responses = [
          "I'm analyzing the current security posture. Threat level is elevated at 75%. How can I assist?",
          "I detected anomalies in the network traffic. Investigate further?",
          "Based on threat intel, APT activity is rising. Want a detailed report?",
          "Metrics show room for improvement. I can suggest optimizations."
        ];
        aiResponse = responses[Math.floor(Math.random() * responses.length)];
      }

      const aiMessage = {
        id: Date.now() + 1,
        type: 'ai',
        message: aiResponse,
        timestamp: new Date()
      };

      setChatMessages(prev => [...prev, aiMessage]);
    }, 1500);
  };

  const renderModule = () => {
    switch (activeModule) {
      case 'dashboard': return <Dashboard setSelectedAlert={setSelectedAlert} />;
      case 'vulnscanner': return <VulnScanner />;
      case 'malware': return <MalwareAgent />;
      case 'threatintel': return <ThreatIntel />;
      case 'forecasting': return <Forecasting />;
      case 'memory': return <KnowledgeBase />;
      case 'response': return <ResponseAgent />;
      case 'forensic': return <ForensicAgent />;
      case 'settings': return <Settings />;
      default: return <Dashboard setSelectedAlert={setSelectedAlert} />;
    }
  };

  return (
    <div className={`min-h-screen ${isDark ? 'bg-gray-900 text-white' : 'bg-gray-100 text-black'}`}>
      {/* Header */}
      <Header
        currentTime={currentTime}
        isDark={isDark}
        setIsDark={setIsDark}
        setChatOpen={setHoveringChatOpen}
      />

      <div className="flex">
        {/* Sidebar */}
        <Sidebar activeModule={activeModule} setActiveModule={setActiveModule} />

        {/* Main Content */}
        <main className="flex-1 p-6">
          {renderModule()}
        </main>
      </div>

      {/* Hovering Chat Assistant */}
      <HoveringChatBox
        isOpen={hoveringChatOpen}
        onToggle={() => setHoveringChatOpen(!hoveringChatOpen)}
        messages={chatMessages}
        currentMessage={currentMessage}
        setCurrentMessage={setCurrentMessage}
        onSendMessage={handleChatMessage}
        activeModule={activeModule}
      />

      {/* Alert Modal */}
      {selectedAlert && (
        <AlertModal alert={selectedAlert} setSelectedAlert={setSelectedAlert} />
      )}

      {/* Floating Chat Button */}
      {!hoveringChatOpen && (
        <button
          onClick={() => setHoveringChatOpen(true)}
          className="fixed bottom-4 right-4 p-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 shadow-lg"
        >
          <MessageSquare size={24} />
        </button>
      )}
    </div>
  );
};

export default App;