import React from 'react';
import { TrendingUp, Brain, Shield } from 'lucide-react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip } from 'recharts';

const forecastData = [
  { category: 'Malware', current: 85, predicted: 92 },
  { category: 'Phishing', current: 65, predicted: 71 },
  { category: 'DDoS', current: 45, predicted: 38 }
];

const Forecasting = () => (
  <div className="space-y-6">
    <div className="bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-lg">
      <h3 className="text-xl text-white mb-4 flex items-center"><TrendingUp className="mr-2 text-green-400" /> 7-Day Threat Forecast</h3>
      <ResponsiveContainer width="100%" height={250}>
        <RadarChart data={forecastData}>
          <PolarGrid stroke="#374151" />
          <PolarAngleAxis dataKey="category" tick={{ fill: '#9CA3AF' }} />
          <PolarRadiusAxis tick={{ fill: '#9CA3AF' }} />
          <Radar name="Current" dataKey="current" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.3} />
          <Radar name="Predicted" dataKey="predicted" stroke="#EF4444" fill="#EF4444" fillOpacity={0.2} />
          <Tooltip contentStyle={{ backgroundColor: '#1F2937' }} />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  </div>
);

export default Forecasting;
