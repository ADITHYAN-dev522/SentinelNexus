"""
MITRE ATT&CK Utility - Map techniques and tactics
"""

class MitreAttack:
    def __init__(self):
        # Simplified MITRE ATT&CK technique database
        self.techniques = {
            'T1003': {
                'name': 'OS Credential Dumping',
                'description': 'Adversaries may attempt to dump credentials to obtain account login information',
                'tactics': ['Credential Access']
            },
            'T1021': {
                'name': 'Remote Services',
                'description': 'Adversaries may use valid accounts to log into remote services',
                'tactics': ['Lateral Movement']
            },
            'T1021.001': {
                'name': 'Remote Desktop Protocol',
                'description': 'Adversaries may use RDP to remotely control systems',
                'tactics': ['Lateral Movement']
            },
            'T1021.002': {
                'name': 'SMB/Windows Admin Shares',
                'description': 'Adversaries may use SMB to interact with remote systems',
                'tactics': ['Lateral Movement']
            },
            'T1041': {
                'name': 'Exfiltration Over C2 Channel',
                'description': 'Adversaries may steal data by exfiltrating over existing C2 channel',
                'tactics': ['Exfiltration']
            },
            'T1055': {
                'name': 'Process Injection',
                'description': 'Adversaries may inject code into processes to evade defenses',
                'tactics': ['Defense Evasion', 'Privilege Escalation']
            },
            'T1068': {
                'name': 'Exploitation for Privilege Escalation',
                'description': 'Adversaries may exploit software vulnerabilities to elevate privileges',
                'tactics': ['Privilege Escalation']
            },
            'T1071.001': {
                'name': 'Web Protocols',
                'description': 'Adversaries may communicate using application layer protocols',
                'tactics': ['Command and Control']
            },
            'T1078': {
                'name': 'Valid Accounts',
                'description': 'Adversaries may obtain and abuse credentials of existing accounts',
                'tactics': ['Defense Evasion', 'Persistence', 'Privilege Escalation', 'Initial Access']
            },
            'T1082': {
                'name': 'System Information Discovery',
                'description': 'Adversaries may attempt to get detailed information about the system',
                'tactics': ['Discovery']
            },
            'T1083': {
                'name': 'File and Directory Discovery',
                'description': 'Adversaries may enumerate files and directories',
                'tactics': ['Discovery']
            },
            'T1105': {
                'name': 'Ingress Tool Transfer',
                'description': 'Adversaries may transfer tools or files to victim systems',
                'tactics': ['Command and Control']
            },
            'T1110.003': {
                'name': 'Password Spraying',
                'description': 'Adversaries may use password spraying to gain access',
                'tactics': ['Credential Access']
            },
            'T1110.004': {
                'name': 'Credential Stuffing',
                'description': 'Adversaries may use credentials from breaches',
                'tactics': ['Credential Access']
            },
            'T1113': {
                'name': 'Screen Capture',
                'description': 'Adversaries may capture screen content',
                'tactics': ['Collection']
            },
            'T1190': {
                'name': 'Exploit Public-Facing Application',
                'description': 'Adversaries may exploit weaknesses in Internet-facing applications',
                'tactics': ['Initial Access']
            },
            'T1204.002': {
                'name': 'Malicious File',
                'description': 'Adversaries may rely on users opening malicious files',
                'tactics': ['Execution']
            },
            'T1486': {
                'name': 'Data Encrypted for Impact',
                'description': 'Adversaries may encrypt data to disrupt availability',
                'tactics': ['Impact']
            },
            'T1489': {
                'name': 'Service Stop',
                'description': 'Adversaries may stop or disable services',
                'tactics': ['Impact']
            },
            'T1490': {
                'name': 'Inhibit System Recovery',
                'description': 'Adversaries may delete or remove recovery mechanisms',
                'tactics': ['Impact']
            },
            'T1505.003': {
                'name': 'Web Shell',
                'description': 'Adversaries may install web shells for persistence',
                'tactics': ['Persistence']
            },
            'T1547.001': {
                'name': 'Registry Run Keys / Startup Folder',
                'description': 'Adversaries may achieve persistence via registry',
                'tactics': ['Persistence', 'Privilege Escalation']
            },
            'T1562': {
                'name': 'Impair Defenses',
                'description': 'Adversaries may maliciously modify security tools',
                'tactics': ['Defense Evasion']
            },
            'T1562.001': {
                'name': 'Disable or Modify Tools',
                'description': 'Adversaries may disable security tools',
                'tactics': ['Defense Evasion']
            },
            'T1566': {
                'name': 'Phishing',
                'description': 'Adversaries may send phishing messages to gain access',
                'tactics': ['Initial Access']
            },
            'T1566.001': {
                'name': 'Spearphishing Attachment',
                'description': 'Adversaries may send emails with malicious attachments',
                'tactics': ['Initial Access']
            },
            'T1056.001': {
                'name': 'Keylogging',
                'description': 'Adversaries may log user keystrokes',
                'tactics': ['Collection', 'Credential Access']
            },
            'T1087': {
                'name': 'Account Discovery',
                'description': 'Adversaries may attempt to get lists of accounts',
                'tactics': ['Discovery']
            },
            'T1018': {
                'name': 'Remote System Discovery',
                'description': 'Adversaries may attempt to discover remote systems',
                'tactics': ['Discovery']
            },
            'T1550.002': {
                'name': 'Pass the Hash',
                'description': 'Adversaries may pass the hash to authenticate',
                'tactics': ['Defense Evasion', 'Lateral Movement']
            },
            'T1213.002': {
                'name': 'Sharepoint',
                'description': 'Adversaries may access Sharepoint repositories',
                'tactics': ['Collection']
            },
            'T1560.001': {
                'name': 'Archive via Utility',
                'description': 'Adversaries may use utilities to compress data',
                'tactics': ['Collection']
            },
            'T1074.001': {
                'name': 'Local Data Staging',
                'description': 'Adversaries may stage collected data locally',
                'tactics': ['Collection']
            },
            'T1595.002': {
                'name': 'Vulnerability Scanning',
                'description': 'Adversaries may scan for vulnerabilities',
                'tactics': ['Reconnaissance']
            },
            'T1059.004': {
                'name': 'Unix Shell',
                'description': 'Adversaries may abuse Unix shells',
                'tactics': ['Execution']
            },
            'T1020': {
                'name': 'Automated Exfiltration',
                'description': 'Adversaries may use automated methods to exfiltrate data',
                'tactics': ['Exfiltration']
            },
            'T1567': {
                'name': 'Exfiltration Over Web Service',
                'description': 'Adversaries may exfiltrate data to cloud storage',
                'tactics': ['Exfiltration']
            },
            'T1114': {
                'name': 'Email Collection',
                'description': 'Adversaries may target email to collect information',
                'tactics': ['Collection']
            },
            'T1213': {
                'name': 'Data from Information Repositories',
                'description': 'Adversaries may access information repositories',
                'tactics': ['Collection']
            }
        }
    
    def get_technique_info(self, technique_id):
        """Get information about a specific MITRE ATT&CK technique"""
        return self.techniques.get(technique_id, {
            'name': 'Unknown Technique',
            'description': 'No description available',
            'tactics': ['Unknown']
        })
    
    def get_techniques_by_tactic(self, tactic):
        """Get all techniques for a specific tactic"""
        return [
            {'id': tid, **info}
            for tid, info in self.techniques.items()
            if tactic in info['tactics']
        ]
