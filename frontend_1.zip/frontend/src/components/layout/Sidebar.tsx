import React from 'react';
import { Shield, Scan, Bug, Globe, Play, FileSearch, TrendingUp, Database, Settings } from 'lucide-react';

const modules = [
  { id: 'dashboard', name: 'Dashboard', icon: Shield },
  { id: 'vulnscanner', name: 'VulnScanner', icon: Scan },
  { id: 'malware', name: 'Malware Agent', icon: Bug },
  { id: 'threatintel', name: 'ThreatIntel Agent', icon: Globe },
  { id: 'response', name: 'Response Agent', icon: Play },
  { id: 'forensic', name: 'Forensic Agent', icon: FileSearch },
  { id: 'forecasting', name: 'Forecasting Agent', icon: TrendingUp },
  { id: 'memory', name: 'Knowledge Base', icon: Database },
  { id: 'settings', name: 'Settings', icon: Settings }
];

const Sidebar = ({ activeModule, setActiveModule }) => (
  <aside className="w-64 bg-gray-800 border-r border-gray-700 min-h-screen">
    <nav className="p-4 space-y-2">
      {modules.map((module) => {
        const Icon = module.icon;
        return (
          <button
            key={module.id}
            onClick={() => setActiveModule(module.id)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
              activeModule === module.id ? 'bg-blue-600 text-white' : 'text-gray-300 hover:bg-gray-700 hover:text-white'
            }`}
          >
            <Icon size={20} />
            <span>{module.name}</span>
          </button>
        );
      })}
    </nav>
  </aside>
);

export default Sidebar;
