"""
Red Team Simulator - Attack Scenario Testing
Simulates real-world attacks to test detection capabilities
"""

import random
from datetime import datetime

class RedTeamSimulator:
    def __init__(self):
        self.scenarios = [
            {
                'name': 'Credential Stuffing Attack',
                'description': 'Automated login attempts using compromised credentials',
                'severity': 'high',
                'mitre_techniques': ['T1110.004', 'T1078'],
                'steps': [
                    {'action': 'Enumerate valid usernames', 'technique': 'T1087', 'description': 'OSINT gathering'},
                    {'action': 'Attempt password spraying', 'technique': 'T1110.003', 'description': 'Try common passwords'},
                    {'action': 'Use leaked credential database', 'technique': 'T1110.004', 'description': 'Credential stuffing'},
                    {'action': 'Successfully authenticate', 'technique': 'T1078', 'description': 'Valid account access'}
                ]
            },
            {
                'name': 'Ransomware Simulation',
                'description': 'Full ransomware attack chain from initial access to encryption',
                'severity': 'critical',
                'mitre_techniques': ['T1566', 'T1204', 'T1486'],
                'steps': [
                    {'action': 'Send phishing email', 'technique': 'T1566.001', 'description': 'Spearphishing attachment'},
                    {'action': 'User downloads payload', 'technique': 'T1204.002', 'description': 'Malicious file execution'},
                    {'action': 'Establish persistence', 'technique': 'T1547.001', 'description': 'Registry run keys'},
                    {'action': 'Disable security tools', 'technique': 'T1562.001', 'description': 'Impair defenses'},
                    {'action': 'Enumerate file shares', 'technique': 'T1083', 'description': 'File and directory discovery'},
                    {'action': 'Encrypt files', 'technique': 'T1486', 'description': 'Data encrypted for impact'}
                ]
            },
            {
                'name': 'Lateral Movement Attack',
                'description': 'Network propagation and privilege escalation',
                'severity': 'high',
                'mitre_techniques': ['T1021', 'T1003', 'T1068'],
                'steps': [
                    {'action': 'Initial foothold obtained', 'technique': 'T1190', 'description': 'Exploit public application'},
                    {'action': 'Dump credentials', 'technique': 'T1003.001', 'description': 'LSASS memory'},
                    {'action': 'Network scanning', 'technique': 'T1018', 'description': 'Remote system discovery'},
                    {'action': 'Pass-the-hash attack', 'technique': 'T1550.002', 'description': 'Use alternate authentication'},
                    {'action': 'RDP to another host', 'technique': 'T1021.001', 'description': 'Remote desktop protocol'},
                    {'action': 'Escalate privileges', 'technique': 'T1068', 'description': 'Exploit for privilege escalation'}
                ]
            },
            {
                'name': 'Data Exfiltration',
                'description': 'Steal sensitive data from the network',
                'severity': 'critical',
                'mitre_techniques': ['T1083', 'T1560', 'T1041'],
                'steps': [
                    {'action': 'Locate sensitive data', 'technique': 'T1083', 'description': 'File and directory discovery'},
                    {'action': 'Access database', 'technique': 'T1213.002', 'description': 'Sharepoint'},
                    {'action': 'Compress data', 'technique': 'T1560.001', 'description': 'Archive via utility'},
                    {'action': 'Stage for exfiltration', 'technique': 'T1074.001', 'description': 'Local data staging'},
                    {'action': 'Exfiltrate over C2', 'technique': 'T1041', 'description': 'Exfiltration over command and control'}
                ]
            },
            {
                'name': 'Web Application Attack',
                'description': 'Exploit web application vulnerabilities',
                'severity': 'medium',
                'mitre_techniques': ['T1190', 'T1505.003'],
                'steps': [
                    {'action': 'Scan for vulnerabilities', 'technique': 'T1595.002', 'description': 'Vulnerability scanning'},
                    {'action': 'SQL injection attempt', 'technique': 'T1190', 'description': 'Exploit public-facing application'},
                    {'action': 'Upload web shell', 'technique': 'T1505.003', 'description': 'Web shell installation'},
                    {'action': 'Execute commands', 'technique': 'T1059.004', 'description': 'Unix shell'},
                    {'action': 'Establish backdoor', 'technique': 'T1071.001', 'description': 'Web protocols C2'}
                ]
            }
        ]
        
        self.simulation_history = []
    
    def get_scenarios(self):
        """Get list of available attack scenarios"""
        return self.scenarios
    
    def simulate_attack(self, scenario_name):
        """Run attack simulation"""
        
        # Find scenario
        scenario = next((s for s in self.scenarios if s['name'] == scenario_name), None)
        if not scenario:
            return {'error': 'Scenario not found'}
        
        # Simulate each step
        results = {
            'scenario': scenario_name,
            'timestamp': datetime.now().isoformat(),
            'total_steps': len(scenario['steps']),
            'detected_steps': 0,
            'steps': []
        }
        
        for step in scenario['steps']:
            # Simulate detection (random for demo, would be real detection in production)
            detected = random.random() > 0.3  # 70% detection rate
            
            if detected:
                results['detected_steps'] += 1
                detection_method = random.choice([
                    'Signature-based detection',
                    'Behavioral anomaly detection',
                    'ML-based classification',
                    'SIEM correlation rule',
                    'EDR agent alert'
                ])
            else:
                detection_method = None
            
            results['steps'].append({
                'action': step['action'],
                'technique': step['technique'],
                'description': step['description'],
                'detected': detected,
                'detection_method': detection_method
            })
        
        # Calculate detection rate
        results['detection_rate'] = (results['detected_steps'] / results['total_steps']) * 100
        
        # Store in history
        self.simulation_history.append({
            'scenario': scenario_name,
            'timestamp': results['timestamp'],
            'detection_rate': results['detection_rate']
        })
        
        return results
    
    def get_simulation_history(self):
        """Get history of past simulations"""
        return self.simulation_history
